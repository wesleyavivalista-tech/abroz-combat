import { resolveSkin } from "../../../packages/game-core/characters/skins.js";
import { randomInt } from "node:crypto";
import type { WebSocket } from "ws";
import type { ServerMessage, OnlineMode } from "../../../packages/shared/protocol.js";
import { characters } from "../../../packages/game-core/characters/registry.js";
interface Peer {
  skin: string;
  team: number;
  socket: WebSocket;
  character: string;
  ready: boolean;
  connected: boolean;
  lastFrame: number;
  count: number;
  window: number;
}
interface Room {
  mode: OnlineMode;
  code: string;
  peers: Peer[];
  started: boolean;
  capacity: number;
  created: number;
}
export function send(socket: WebSocket, message: ServerMessage): void {
  if (socket.readyState === 1) socket.send(JSON.stringify(message));
}
export class RoomService {
  rooms = new Map<string, Room>();
  membership = new Map<WebSocket, Room>();
  create(socket: WebSocket, character: string, capacity = 2, mode: OnlineMode = "ffa", team?: number, skin?: string): void {
    if (!["ffa", "2v2", "3v3"].includes(mode)) throw new Error("Invalid match mode");
    if (team !== undefined && team !== 0 && team !== 1) throw new Error("Invalid team");
    if (mode !== "ffa") capacity = mode === "2v2" ? 4 : 6;
    this.validateCharacter(character);
    const selectedSkin = resolveSkin(characters[character], skin);
    if (!Number.isInteger(capacity) || capacity < 2 || capacity > 6)
      throw new Error("Room size must be 2–6 fighters");
    if (this.rooms.size >= 1000) throw new Error("Server full");
    this.leave(socket);
    let code = "";
    do {
      code = Array.from(
        { length: 5 },
        () => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[randomInt(31)],
      ).join("");
    } while (this.rooms.has(code));
    const room: Room = {
      code,
      mode,
      peers: [this.peer(socket, character, mode === "ffa" ? 0 : (team ?? 0), selectedSkin)],
      started: false,
      capacity,
      created: Date.now(),
    };
    this.rooms.set(code, room);
    this.membership.set(socket, room);
    send(socket, { type: "room", code, seat: 0 });
    this.roster(room);
  }
  join(socket: WebSocket, code: string, character: string, requestedTeam?: number, skin?: string): void {
    if (requestedTeam !== undefined && requestedTeam !== 0 && requestedTeam !== 1) throw new Error("Invalid team");
    this.validateCharacter(character);
    const selectedSkin = resolveSkin(characters[character], skin);
    const room = this.rooms.get(code.toUpperCase());
    if (!room) throw new Error("Room not found");
    if (this.membership.get(socket) === room)
      throw new Error("Already in this room");
    if (room.peers.length === room.capacity || room.started)
      throw new Error("Room is full");
    let team = room.peers.length;
    if (room.mode !== "ffa") {
      const counts = [0, 1].map(t => room.peers.filter(p => p.team === t).length);
      team = requestedTeam ?? (counts[0] <= counts[1] ? 0 : 1);
      if (counts[team] >= room.capacity / 2) throw new Error("That team is full. Choose another team or Auto balance.");
    }
    this.leave(socket);
    room.peers.push(this.peer(socket, character, team, selectedSkin));
    this.membership.set(socket, room);
    send(socket, {
      type: "room",
      code: room.code,
      seat: room.peers.length - 1,
    });
    this.roster(room);
  }
  ready(socket: WebSocket): void {
    const room = this.membership.get(socket);
    if (!room) return;
    room.peers.find((p) => p.socket === socket)!.ready = true;
    this.roster(room);
    if (
      room.peers.length === room.capacity &&
      room.peers.every((p) => p.ready) &&
      !room.started
    ) {
      room.started = true;
      const chars = room.peers.map((p) => p.character);
      room.peers.forEach((p) =>
        send(p.socket, {
          type: "start",
          characters: chars,
          teams: room.peers.map(p => p.team),
          skins: room.peers.map(p => p.skin),
          mode: room.mode,
          inputDelay: 2,
          maxRollbackFrames: 8,
        }),
      );
    }
  }
  input(socket: WebSocket, frame: number, mask: number): void {
    const room = this.membership.get(socket);
    if (!room?.started) throw new Error("Match has not started");
    const peer = room.peers.find((p) => p.socket === socket)!;
    if (
      !Number.isInteger(frame) ||
      frame < 0 ||
      frame > 10_000_000 ||
      !Number.isInteger(mask) ||
      mask < 0 ||
      mask > 2047
    )
      throw new Error("Invalid input");
    if (frame !== peer.lastFrame + 1) throw new Error("Out-of-order input");
    const others = room.peers.filter((p) => p !== peer && p.connected);
    if (others.some((other) => frame > other.lastFrame + 120))
      throw new Error("Input too far ahead");
    if (Date.now() - peer.window > 1000) {
      peer.window = Date.now();
      peer.count = 0;
    }
    if (++peer.count > 180) throw new Error("Input rate exceeded");
    peer.lastFrame = frame;
    others.forEach((other) =>
      send(other.socket, {
        type: "input",
        seat: room.peers.indexOf(peer),
        frame,
        mask,
      }),
    );
  }
  relayHash(socket: WebSocket, frame: number, hash: string): void {
    const room = this.membership.get(socket);
    const peer = room?.peers.find((p) => p.socket === socket);
    if (
      !room?.started ||
      !peer ||
      !Number.isInteger(frame) ||
      frame < 0 ||
      frame > peer.lastFrame ||
      frame % 60 !== 0 ||
      !/^[a-f0-9]{1,8}$/.test(hash)
    )
      return;
    room.peers
      .filter((p) => p !== peer && p.connected)
      .forEach((p) =>
        send(p.socket, {
          type: "hash",
          seat: room.peers.indexOf(peer),
          frame,
          hash,
        }),
      );
  }
  leave(socket: WebSocket): void {
    const room = this.membership.get(socket);
    if (!room) return;
    const seat = room.peers.findIndex((p) => p.socket === socket);
    const peer = room.peers[seat];
    this.membership.delete(socket);
    peer.connected = false;
    if (room.started) {
      // Keep seats stable; the first missing input is the deterministic forfeit frame.
      room.peers
        .filter((p) => p.connected)
        .forEach((p) =>
          send(p.socket, { type: "left", seat, frame: peer.lastFrame + 1 }),
        );
    } else {
      room.peers.splice(seat, 1);
      if (room.mode === "ffa") room.peers.forEach((p, i) => p.team = i);
      room.peers.forEach((p, seat) =>
        send(p.socket, { type: "room", code: room.code, seat }),
      );
      this.roster(room);
    }
    if (!room.peers.some((p) => p.connected)) this.rooms.delete(room.code);
  }
  expire(): void {
    for (const room of this.rooms.values())
      if (!room.started && Date.now() - room.created > 15 * 60_000)
        for (const peer of [...room.peers]) {
          send(peer.socket, { type: "error", message: "Waiting room expired" });
          this.leave(peer.socket);
        }
  }
  private roster(room: Room): void {
    room.peers.forEach((peer) =>
      send(peer.socket, {
        type: "roster",
        capacity: room.capacity,
        mode: room.mode,
        players: room.peers.map((p) => ({
          character: p.character,
          ready: p.ready,
          team: p.team,
          skin: p.skin,
        })),
      }),
    );
  }
  private peer(socket: WebSocket, character: string, team: number, skin: string): Peer {
    return {
      skin,
      team,
      socket,
      character,
      ready: false,
      connected: true,
      lastFrame: 1,
      count: 0,
      window: Date.now(),
    };
  }
  private validateCharacter(character: string): void {
    if (typeof character !== "string" || !Object.hasOwn(characters, character))
      throw new Error("Unknown character");
  }
}
