import { fighterSkins, resolveSkin } from "../../../packages/game-core/characters/skins.js";
import type { OnlineMode } from "../../../packages/shared/protocol.js";
import { fighterPresentation, escapeMarkup } from "./ui/FighterPresentation.js";
import "./style.css";
import "./ui/combat-menu.css";
import { homeScreen, selectionScreen } from "./ui/MenuScreens.js";
import "./ui/match-overlays.css";
import { trainingRoom } from "../../../packages/game-core/stages/registry.js";
import { GameSimulation } from "../../../packages/game-core/simulation/GameSimulation.js";
import { characters } from "../../../packages/game-core/characters/registry.js";
import { RollbackManager } from "../../../packages/networking/RollbackManager.js";
import { InputManager, actions } from "./input/InputManager.js";
import { AudioManager } from "./audio/AudioManager.js";
import { AssetManager } from "./assets/AssetManager.js";
import { SceneRenderer } from "./rendering/SceneRenderer.js";
import { LobbyClient } from "./network.js";
import { UI } from "./ui/UI.js";
const ui = new UI(),
  input = new InputManager(),
  audio = new AudioManager(),
  assets = new AssetManager(),
  network = new LobbyClient();
const renderer = new SceneRenderer(
  document.querySelector<HTMLCanvasElement>("#scene")!,
);
let simulation = new GameSimulation(),
  rollback: RollbackManager | null = null;
let screen = "home",
  mode: "local" | "training" | "online" = "local",
  selectSeat = 0,
  seat = 0,
  debug = false,
  paused = false,
  accumulator = 0,
  last = performance.now(),
  fps = 60,
  lastHash = -1;
const playerColors = [
  "#c9ec7a",
  "#ffb18e",
  "#7adfff",
  "#dbadff",
  "#ffdf70",
  "#ff83ba",
];
const rosterIds = Object.keys(characters);
const selected: [string, string] = [rosterIds[0], rosterIds[1] ?? rosterIds[0]];
const selectedSkins = selected.map(id => resolveSkin(characters[id]));
let archiveSkin: string | undefined;
const pendingHashes = new Map<string, { frame: number; hash: string }>();
let archiveId = rosterIds[0];
let viewRevision = 0;
let cancelBinding: (() => void) | undefined;
function navigate(next: string, keepConnection = false) {
  viewRevision++;
  cancelBinding?.();
  if (!keepConnection && mode === "online" && ["lobby", "loading"].includes(screen)) { network.disconnect(); rollback = null; }
  screen = next; input.enabled = false; input.clear();
}
function home() {
  network.disconnect();
  rollback = null;
  navigate("home");
  paused = false;
  input.enabled = false;
  simulation = new GameSimulation();
  simulation.state.fighters[0].x = trainingRoom.width / 2 + 80;
  simulation.state.fighters[1].x = trainingRoom.width / 2 + 380;
  simulation.state.fighters.forEach((f) => (f.state = "Idle"));
  renderHome();
}
function renderHome() {
  ui.shell(homeScreen(), "PICK YOUR MODE. MAKE YOUR MARK.", false);
}

function selection(roster = false) {
  navigate(roster ? "roster" : "select");
  input.enabled = false;
  ui.shell(selectionScreen(mode, selected, selectSeat, roster, archiveId, selectedSkins, archiveSkin),
    `TWO SPECIALS · TWO SUPERS · THREE LIVES`);
  document.getElementById("fighter-skin")?.addEventListener("change", event => {
    const value = (event.target as HTMLSelectElement).value;
    if (roster) archiveSkin = resolveSkin(characters[archiveId], value);
    else selectedSkins[selectSeat] = resolveSkin(characters[selected[selectSeat]], value);
    selection(roster);
    document.getElementById("fighter-skin")?.focus();
  });
}

function stage() {
  navigate("stage");
  ui.shell(
    `<main class="arena-screen"><img class="arena-panorama" src="/art/rooftop-city-v1.png" alt="Sunset over the rooftop arena"><div class="arena-heading"><span>02 / ARENA SELECT</span><h2>THE<br>ROOFTOP</h2><p>Above the streets. Beyond your limits.</p></div><div class="arena-bottom"><div class="arena-facts"><span>NEW YORK INSPIRED</span><b>24 METRES</b><span>TWO ELEVATED PLATFORMS<br>THREE LIVES / LAST FIGHTER STANDING</span></div><div class="arena-launch-panel"><div class="arena-matchup">${(mode === "online" ? [selected[0]] : selected).map((id, i) => `<div><img src="${fighterPresentation(id, selectedSkins[i]).portrait}" alt=""><span>${mode === "online" ? "YOUR FIGHTER" : mode === "training" && i === 1 ? "DUMMY" : `P${i + 1}`}<b>${characters[id].displayName}</b></span></div>`).join('<i>VS</i>')}</div><button class="ac-cta" data-action="launch"><span>${mode === "online" ? "CONTINUE TO LOBBY" : "ENTER THE ARENA"}</span><b>→</b></button><button class="arena-change" data-action="back-fighters">← CHANGE FIGHTERS</button></div></div></main>`,
  );
}
async function start(ids: string[] = selected, teams?: number[], skins: string[] = selectedSkins) {
  navigate("loading", true);
  const revision = viewRevision;
  input.enabled = false;
  ui.shell(
    '<main class="page"><div class="eyebrow">GETTING READY</div><h2>ENTERING THE ROOFTOP</h2><div class="loading-bar"><i id="load-progress" style="width:0%"></i></div></main>',
  );
  simulation = new GameSimulation(ids, mode === "training", undefined, teams, skins);
  if (mode === "online") {
    rollback = new RollbackManager(simulation, seat, 2, 8);
    lastHash = -1;
    pendingHashes.clear();
  } else rollback = null;
  try {
  await Promise.all([renderer.stage.ready, renderer.prepareFighters()]);
  await assets.load(
    Object.assign({}, ...ids.map((id) => characters[id].assets)),
    (p) => {
      const el = document.getElementById("load-progress");
      if (el) el.style.width = `${p * 100}%`;
    },
  );
  } catch (error) {
    if (revision !== viewRevision) return;
    disconnectMessage(error instanceof Error ? error.message : "Could not load fighter assets.");
    return;
  }
  if (revision !== viewRevision || screen !== "loading") return;
  screen = "fight";
  paused = false;
  accumulator = 0;
  input.clear();
  input.enabled = true;
  hud();
}
function controlLabels(player: number): string {
  const keys = input.bindings[player].map(key => escapeMarkup(key.replace("Key", "").replace("Digit", "").replace("Arrow", "")));
  const badge = (text: string) => `<span class="key">${text}</span>`;
  return `${badge(keys.slice(0, 4).join(" / "))} MOVE · TAP UP AGAIN IN AIR TO DOUBLE JUMP ${badge(keys[4])} COMBO · ${badge(keys[5])} HEAVY · ${badge(keys[6])} ATTACK 3 ${badge(keys.slice(7, 9).join(" / "))} SPECIALS ${badge(keys.slice(9, 11).join(" / "))} SUPERS`;
}
function hud() {
  ui.render(
    `<div style="--fighter-count:${simulation.state.fighters.length}" class="hud ${simulation.state.teamMatch ? "team-hud" : ""} ${simulation.state.fighters.length > 2 ? "multi-hud" : ""}">${simulation.state.fighters.length > 2 ? simulation.state.fighters.map((_, i) => fighterHud(i)).join("") : `${fighterHud(0)}<div class="timer"><span id="match-symbol">VS</span><small id="match-mode">SURVIVAL</small></div>${fighterHud(1)}`}</div><div id="player-tags"></div><div class="announcement" id="announcement"></div><div class="combo" id="combo0"></div><div class="combo right" id="combo1"></div><pre class="debug" id="debug" hidden></pre>${mode === "training" ? `<div class="training"><span class="pill">TRAINING</span><label>DUMMY <select id="dummy"><option value="stand" ${simulation.trainingOptions.dummy === "stand" ? "selected" : ""}>Stand</option><option value="crouch" ${simulation.trainingOptions.dummy === "crouch" ? "selected" : ""}>Crouch</option><option value="jump" ${simulation.trainingOptions.dummy === "jump" ? "selected" : ""}>Jump</option><option value="block" ${simulation.trainingOptions.dummy === "block" ? "selected" : ""}>Block all low / mid</option><option value="afterHit" ${simulation.trainingOptions.dummy === "afterHit" ? "selected" : ""}>Block after hit</option></select></label><label><input id="infinite" type="checkbox" ${simulation.trainingOptions.infiniteMeter ? "checked" : ""}> ∞ METER</label><button data-action="reset">RESET [R]</button><button data-action="debug">BOXES [F1]</button><span id="damage">DAMAGE 0 / COMBO 0</span></div>` : ""}<div class="combat-footer"><span>${mode === "online" ? '<span class="dot"></span> ONLINE' + (simulation.state.teamMatch ? ` ${simulation.state.fighters.length / 2}v${simulation.state.fighters.length / 2}` : '') + ' · YOU ARE P' + (seat + 1) + teamLabel(seat) : mode === "training" ? "TRAINING · INFINITE HEALTH" : "LOCAL VERSUS"} &nbsp; ${controlLabels(0)} ${mode === "local" ? " / P2 " + controlLabels(1) : ""}</span><button class="text-button" data-action="pause">${mode === "online" ? "LEAVE" : "PAUSE"} [ESC]</button></div>`,
  );
  document
    .getElementById("dummy")
    ?.addEventListener(
      "change",
      (e) =>
        (simulation.trainingOptions.dummy = (e.target as HTMLSelectElement)
          .value as typeof simulation.trainingOptions.dummy),
    );
  document
    .getElementById("infinite")
    ?.addEventListener(
      "change",
      (e) =>
        (simulation.trainingOptions.infiniteMeter = (
          e.target as HTMLInputElement
        ).checked),
    );
}
const teamNames = ["BLUE", "RED"];
const teamColors = ["#7adfff", "#ff8575"];
function fighterColor(i: number) { return simulation.state.teamMatch ? teamColors[simulation.state.teams[i]] : playerColors[i]; }
function teamLabel(i: number) { return simulation.state.teamMatch ? ` · ${teamNames[simulation.state.teams[i]]}` : ""; }
function fighterHud(i: number) {
  return `<div class="p${i + 1} ${mode === "online" && i === seat ? "you" : ""}" style="--player-color:${fighterColor(i)};order:${simulation.state.teamMatch ? simulation.state.teams[i] * 10 + i : i}"><div class="fighter-name"><img class="hud-portrait" src="${fighterPresentation(simulation.state.fighters[i].characterId, simulation.state.skins[i]).portrait}" alt=""><b>${characters[simulation.state.fighters[i].characterId].displayName}</b><span>P${i + 1}${teamLabel(i)}${mode === "online" && i === seat ? " · YOU" : ""}</span></div><div class="health"><i id="health${i}"></i></div><div class="meter"><i id="meter${i}"></i></div><div class="super-slots" id="supers${i}"></div><div class="lives" id="lives${i}"></div><div class="life-status" id="life-status${i}"></div></div>`;
}
function updateHUD() {
  const s = simulation.state;
  ui.text("match-symbol", s.training ? "∞" : "VS");
  ui.text("match-mode", s.training ? "TRAINING" : "SURVIVAL");
  s.fighters.forEach((f, i) => {
    document.getElementById("health" + i)!.style.width =
      `${(f.health / characters[f.characterId].stats.maxHealth) * 100}%`;
    document.getElementById("meter" + i)!.style.width = `${f.meter}%`;
    document.getElementById("supers" + i)!.innerHTML = characters[
      f.characterId
    ].superButtons
      .map((id, n) => {
        const spent = f.usedSupers.includes(id),
          ready = !spent && f.meter >= 100;
        const key = mode === "online" && i !== seat ? "" : input.bindings[mode === "online" ? 0 : i][9 + n]
          .replace("Key", "")
          .replace("Digit", "");
        return `<span class="super-slot ${spent ? "spent" : ready ? "ready" : ""}" title="${characters[f.characterId].moves[id].displayName ?? id} · Full energy required. Once per match.">${key ? `<b>${escapeMarkup(key)}</b>` : ""} ${s.fighters.length > 2 ? `SUPER ${n + 1}` : (characters[f.characterId].moves[id].displayName ?? id)} <em>${spent ? "USED" : ready ? "READY" : "CHARGE"}</em></span>`;
      })
      .join("");
    const lives = document.getElementById("lives" + i)!;
    lives.innerHTML =
      [0, 1, 2]
        .map((n) => `<i class="${n < f.lives ? "remaining" : ""}"></i>`)
        .join("") +
      `<span>${s.training ? "∞ LIVES" : f.lives + " " + (f.lives === 1 ? "LIFE" : "LIVES")}</span>`;
    lives.setAttribute(
      "aria-label",
      s.training ? "Unlimited lives" : `${f.lives} lives remaining`,
    );
    ui.text(
      "life-status" + i,
      f.respawnAt > 0
        ? `RESPAWNING IN ${((f.respawnAt - s.frame) / 60).toFixed(1)}s`
        : f.invulnerableUntil > s.frame
          ? `PROTECTED · ${((f.invulnerableUntil - s.frame) / 60).toFixed(1)}s`
          : f.lives === 0
            ? rollback?.departures.has(i)
              ? "DISCONNECTED"
              : "ELIMINATED"
            : [f.onFireUntil > s.frame ? `ON FIRE · ${Math.ceil((f.onFireUntil - s.frame) / 60)}s · +50% SPEED` : "", f.burnUntil >= s.frame && f.burnUntil > 0 ? `BURN · ${Math.ceil((f.burnUntil - s.frame) / 60)}s` : ""].filter(Boolean).join(" / "),
    );
    const combo = document.getElementById("combo" + (1 - i));
    if (s.fighters.length === 2 && combo)
      combo.innerHTML =
        f.combo > 1
          ? `${f.combo} HITS<small>${f.comboDamage} DAMAGE</small>`
          : "";
  });
  const announcement = document.getElementById("announcement")!;
  if (s.phase === "intro")
    announcement.innerHTML =
      s.phaseFrame < 55 ? "3 LIVES" : s.phaseFrame < 110 ? "READY" : "FIGHT!";
  else
    announcement.textContent = rollback?.stalled
      ? "WAITING FOR INPUT"
      : s.phase === "result" && rollback
        ? "CONFIRMING RESULT…"
        : mode === "online" && s.fighters[seat].lives === 0
          ? "ELIMINATED · WATCHING THE FIGHT"
          : "";
  ui.text(
    "damage",
    `DAMAGE ${s.fighters[1].lastDamage} / COMBO ${s.fighters[1].comboDamage}`,
  );
  const panel = document.getElementById("debug")!;
  panel.hidden = !debug;
  renderer.debug = debug;
  if (debug) {
    const f = s.fighters[0],
      m = f.move ? characters[f.characterId].moves[f.move] : undefined;
    panel.textContent = `COMBAT LAB / F1\nFPS ${Math.round(fps)} | TICK 60 Hz | FRAME ${s.frame}\n${s.fighters
      .map(
        (f, i) =>
          `P${i + 1} ${f.state} [${f.stateFrame}]\nPOS ${f.x},${f.y} VEL ${f.vx},${f.vy}\nHP ${f.health} METER ${f.meter} FACE ${f.facing}\nLIVES ${f.lives} RESPAWN ${Math.max(0, f.respawnAt - s.frame)}f SHIELD ${Math.max(0, f.invulnerableUntil - s.frame)}f\nANIM ${f.move ?? f.state} / ${f.moveFrame}\nINPUT ${f.buffer
            .slice(-12)
            .map((b) => b.direction)
            .join(" ")}`,
      )
      .join(
        "\n",
      )}\n${m ? `START ${m.startupFrames} ACTIVE ${m.activeFrames} REC ${m.recoveryFrames}` : "NO ACTIVE MOVE"}\nBOXES: HIT pink / HURT blue / PUSH lime\nNETWORK ${rollback ? "ONLINE" : "LOCAL"}\nPING ${network.ping}ms | DELAY ${rollback?.inputDelay ?? 0}f\nROLLBACK ${rollback?.rollbackCount ?? 0} / ${rollback?.rollbackFrames ?? 0}f\nREMOTE ${rollback?.remoteFrame ?? "—"}\nDESYNC ${rollback?.desync ?? "OK"}\nSIMULATED LATENCY ${network.latency}ms`;
  }
  if (
    s.phase === "result" &&
    screen === "fight" &&
    (!rollback || rollback.confirmed >= s.endedAt - 1)
  ) {
    screen = "result";
    input.enabled = false;
    const winner = s.winner < 0 ? null : s.fighters[s.winner];
    const winnerName = winner ? (s.teamMatch ? `${teamNames[s.teams[s.winner]]} TEAM` : characters[winner.characterId].displayName) : "DRAW";
    ui.root.insertAdjacentHTML(
      "beforeend",
      `<dialog class="match-overlay result-overlay ${winner ? "" : "is-draw"}" id="match-result" aria-labelledby="result-title"><div class="result-art" aria-hidden="true">${winner ? `<img src="${fighterPresentation(winner.characterId, s.skins[s.winner]).portrait}" alt="">` : ""}</div><div class="result-topline"><span>ABROZ COMBAT</span><span>MATCH COMPLETE / THE ROOFTOP</span></div><section class="result-content"><span class="overlay-kicker">${winner ? (s.teamMatch ? `${winnerName} / LAST TEAM STANDING` : `PLAYER ${s.winner + 1} / LAST FIGHTER STANDING`) : "NO FIGHTER LEFT STANDING"}</span><h2 id="result-title">${winner ? "VICTORY" : "DRAW"}</h2>${winner ? `<p class="result-winner">${winnerName}</p>` : '<p class="result-draw-note">The rooftop belongs to no one.</p>'}<div class="result-score-heading"><span>FINAL STANDINGS</span><span>LIVES REMAINING</span></div><ol class="result-scoreboard">${s.fighters.map((f, i) => `<li class="${s.winner >= 0 && s.teams[i] === s.teams[s.winner] ? "is-winner" : ""}"><span class="result-seat">P${i + 1}${teamLabel(i)}</span><strong>${characters[f.characterId].displayName}</strong><span class="result-life-count"><b>${f.lives}</b><span aria-hidden="true">${Array.from({ length: 3 }, (_, n) => `<i class="${n < f.lives ? "remaining" : ""}"></i>`).join("")}</span></span></li>`).join("")}</ol><div class="overlay-actions">${mode !== "online" ? '<button class="overlay-action main-action" data-action="rematch"><span>RUN IT BACK<small>Rematch with the same fighters</small></span><b aria-hidden="true">↗</b></button>' : ""}<button class="overlay-action" data-action="home"><span>MAIN MENU<small>Choose your next fight</small></span><b aria-hidden="true">→</b></button></div></section><div class="result-bottomline"><span>${mode === "online" ? (s.teamMatch ? `ONLINE ${s.fighters.length / 2} VS ${s.fighters.length / 2}` : "ONLINE FREE-FOR-ALL") : "LOCAL VERSUS"}</span><span>${s.teamMatch ? "THREE LIVES EACH. ONE WINNING TEAM." : "THREE LIVES. ONE SURVIVOR."}</span></div></dialog>`,
    );
    const resultDialog = document.getElementById("match-result") as HTMLDialogElement;
    resultDialog.showModal();
    resultDialog.addEventListener("cancel", (event) => event.preventDefault());
  }
}
function settings() {
  navigate("settings");
  input.enabled = false;
  ui.shell(
    `<main class="page"><div class="eyebrow">MAKE IT YOURS</div><h2>SETTINGS</h2><div class="settings-grid"><section><span class="tag">AUDIO & NETWORK</span>${(["master", "music", "sound"] as const).map((k) => `<label class="setting">${k.toUpperCase()} VOLUME<input type="range" min="0" max="1" step=".01" value="${audio[k]}" data-volume="${k}"></label>`).join("")}<label class="setting">Diagnostics<input id="diagnostics" type="checkbox" ${debug ? "checked" : ""}></label><label class="setting">Simulated outbound delay<select id="latency">${[0, 50, 100, 150, 200].map((n) => `<option ${network.latency === n ? "selected" : ""} value="${n}">${n} ms</option>`).join("")}</select></label><label class="setting">Add 0–20ms jitter<input id="jitter" type="checkbox" ${network.jitter ? "checked" : ""}></label><p>At high latency, the 8-frame prediction limit may pause combat until input arrives.</p><span class="tag">GAMEPAD ATTACK BUTTONS</span>${["Combo attack", "Heavy attack", "Attack 3", "Special 1", "Special 2", "Super 1", "Super 2"].map((a, i) => `<label class="setting">${a}<select data-pad="${i}">${Array.from({ length: 16 }, (_, n) => `<option value="${n}" ${input.gamepadButtons[i] === n ? "selected" : ""}>Button ${n}</option>`).join("")}</select></label>`).join("")}</section><section><span class="tag">KEYBOARD · CLICK A KEY TO REBIND</span>${actions.map((a, i) => `<div class="setting"><span>${a}</span><button class="bind" data-action="bind" data-player="0" data-index="${i}">${input.bindings[0][i]}</button><button class="bind" data-action="bind" data-player="1" data-index="${i}">${input.bindings[1][i]}</button></div>`).join("")}<p>Columns: Player 1 / Player 2.<br>Gamepads use left stick or D-pad. Default attacks: A / X / B / Y / RB / LT / RT. Connect two controllers for local versus.</p></section></div></main>`,
  );
  ui.root.querySelectorAll<HTMLInputElement>("[data-volume]").forEach(
    (el) =>
      (el.oninput = () => {
        audio[el.dataset.volume as "master" | "music" | "sound"] = Number(
          el.value,
        );
        audio.update();
      }),
  );
  document.getElementById("diagnostics")!.onchange = (e) =>
    (debug = (e.target as HTMLInputElement).checked);
  document.getElementById("latency")!.onchange = (e) =>
    (network.latency = Number((e.target as HTMLSelectElement).value));
  document.getElementById("jitter")!.onchange = (e) =>
    (network.jitter = (e.target as HTMLInputElement).checked);
  ui.root.querySelectorAll<HTMLSelectElement>("[data-pad]").forEach(
    (el) =>
      (el.onchange = () => {
        input.gamepadButtons[Number(el.dataset.pad)] = Number(el.value);
        input.save();
      }),
  );
}
function lobby() {
  navigate("lobby");
  ui.shell(
    `<main class="page online-lobby"><div class="eyebrow">PRIVATE ONLINE VERSUS</div><h2>GATHER YOUR FIGHTERS</h2><p>Free-for-all · 2 vs 2 · 3 vs 3<br>Three lives each. Last fighter or team standing wins.<br>Your fighter: ${characters[selected[0]].displayName}</p><div class="network-panel"><div class="room-setup-grid"><section><label class="setting">MATCH MODE<select id="online-mode" aria-label="Match mode"><option value="ffa">Free-for-all</option><option value="2v2">2 vs 2 — Teams</option><option value="3v3">3 vs 3 — Teams</option></select></label><label class="setting" id="room-size-setting">FIGHTERS IN ROOM<select id="room-size" aria-label="Fighters in room">${[2, 3, 4, 5, 6].map((n) => `<option value="${n}">${n} fighters</option>`).join("")}</select></label><p id="team-rules" class="tag">Every fighter for themselves.</p><label class="setting">YOUR TEAM <select id="preferred-team" aria-label="Your team"><option value="auto">Auto balance</option><option value="0">Blue team</option><option value="1">Red team</option></select></label><small>Team choice applies when creating or joining a team room.</small></section><section class="room-connect"><button class="primary" data-action="create">CREATE ROOM ↗</button><p>Or enter your opponent’s five-character code.</p><div class="row"><input id="code" type="text" placeholder="ABX42" maxlength="5" aria-label="Room code" style="width:150px;text-transform:uppercase;letter-spacing:4px"><button class="secondary" data-action="join">JOIN ROOM</button></div><p id="network-status"></p></section></div></div><p class="tag">Team rooms start with 4 or 6 fighters. Friendly fire is off. Each player uses their own device.<br>Disconnected fighters forfeit. Everyone else keeps playing.</p></main>`,
  );
  document.getElementById("online-mode")!.addEventListener("change", () => {
    const matchMode = (document.getElementById("online-mode") as HTMLSelectElement).value;
    document.getElementById("room-size-setting")!.hidden = matchMode !== "ffa";
    ui.text("team-rules", matchMode === "ffa" ? "Every fighter for themselves." : `${matchMode === "2v2" ? 4 : 6} fighters · Blue vs Red · No friendly fire · Three lives each`);
  });
}
let connectionAttempt = 0;
async function connect(create: boolean) {
  const attempt = ++connectionAttempt;
  const code = (document.getElementById("code") as HTMLInputElement)?.value
    .trim()
    .toUpperCase();
  if (!create && !/^[A-Z0-9]{5}$/.test(code)) {
    ui.text("network-status", "Enter a five-character room code.");
    return;
  }
  const revision = viewRevision;
  const capacity = Number((document.getElementById("room-size") as HTMLSelectElement)?.value ?? 2);
  const character = selected[0];
  const skin = selectedSkins[0];
  const matchMode = (document.getElementById("online-mode") as HTMLSelectElement).value as OnlineMode;
  const preference = (document.getElementById("preferred-team") as HTMLSelectElement).value;
  const team = preference === "auto" ? undefined : Number(preference);
  ui.text("network-status", "Connecting to room server…");
  try {
    await network.connect();
    if (attempt !== connectionAttempt || revision !== viewRevision || screen !== "lobby") return;
    network.send(
      create
        ? {
            type: "create",
            character,
            skin,
            capacity,
            mode: matchMode,
            team,
          }
        : { type: "join", code, character, team, skin },
    );
  } catch (e) {
    if (attempt !== connectionAttempt || revision !== viewRevision || screen !== "lobby") return;
    ui.text(
      "network-status",
      e instanceof Error ? e.message : "Connection failed",
    );
  }
}
network.onMessage = (message) => {
  switch (message.type) {
    case "room":
      if (screen !== "lobby") return;
      seat = message.seat;
      ui.text("network-status", "Room created. Waiting for an opponent…");
      document.querySelector(".network-panel")!.innerHTML =
        `<span class="tag">ROOM CODE / PLAYER ${seat + 1}</span><div class="room-code">${message.code}</div><p>Share this code with your friends.<br>Waiting for fighters…</p><div id="room-roster"></div><p id="network-status"></p>`;
      network.send({ type: "ready" });
      break;
    case "roster":
      if (screen !== "lobby") return;
      ui.text(
        "network-status",
        `${message.mode === "ffa" ? "FREE-FOR-ALL" : message.mode.toUpperCase()} · ${message.players.length} / ${message.capacity} fighters joined`,
      );
      {
        const roster = document.getElementById("room-roster");
        if (roster)
          roster.innerHTML = Array.from(
            { length: message.capacity },
            (_, i) =>
              `<p style="color:${message.mode !== "ffa" && message.players[i] ? teamColors[message.players[i].team] : playerColors[i]}">P${i + 1}${message.mode !== "ffa" && message.players[i] ? ` · ${teamNames[message.players[i].team]}` : ""} · ${message.players[i] ? characters[message.players[i].character].displayName + " / " + escapeMarkup(fighterSkins(characters[message.players[i].character]).find(skin => skin.id === message.players[i].skin)?.name ?? "Original") + (i === seat ? " · YOU" : "") : "Waiting for player…"}</p>`,
          ).join("");
      }
      break;
    case "start":
      if (screen !== "lobby") return;
      void start(message.characters, message.teams, message.skins);
      break;
    case "input":
      rollback?.receive(message.frame, message.mask, message.seat);
      break;
    case "hash":
      pendingHashes.set(`${message.seat}:${message.frame}`, {
        frame: message.frame,
        hash: message.hash,
      });
      break;
    case "error":
      if (screen === "lobby") ui.text("network-status", message.message);
      else disconnectMessage(message.message);
      break;
    case "left":
      rollback?.disconnect(message.seat, message.frame);
      for (const key of pendingHashes.keys())
        if (key.startsWith(`${message.seat}:`)) pendingHashes.delete(key);
      break;
  }
};
network.onClose = () => {
  if (mode === "online" && (screen === "fight" || screen === "lobby" || screen === "loading"))
    disconnectMessage("Connection to the room server was lost.");
};
function disconnectMessage(message: string) {
  viewRevision++;
  network.disconnect();
  if (document.getElementById("disconnect")) return;
  paused = true;
  input.enabled = false;
  const overlay = document.createElement("div");
  overlay.className = "modal";
  overlay.id = "disconnect";
  const box = document.createElement("div");
  const title = document.createElement("h2");
  title.textContent = "MATCH INTERRUPTED";
  const p = document.createElement("p");
  p.textContent = message;
  const button = document.createElement("button");
  button.className = "primary";
  button.dataset.action = "home";
  button.textContent = "MAIN MENU";
  box.append(title, p, button);
  overlay.append(box);
  ui.root.append(overlay);
}
function pause() {
  if (screen !== "fight") return;
  if (mode === "online") {
    home();
    return;
  }
  paused = !paused;
  input.enabled = !paused;
  if (paused) {
    ui.root.insertAdjacentHTML(
      "beforeend",
      `<dialog class="match-overlay pause-overlay" id="pause" aria-labelledby="pause-title"><div class="pause-match"><span class="overlay-kicker">THE ROOFTOP / ${mode === "training" ? "TRAINING" : "LOCAL VERSUS"}</span><div class="pause-matchup">${simulation.state.fighters.map((f, i) => `<div><span>PLAYER ${i + 1}</span><strong>${characters[f.characterId].displayName}</strong><small>${mode === "training" ? (i === 1 ? "TRAINING PARTNER" : "FREE PRACTICE") : `${f.lives} ${f.lives === 1 ? "LIFE" : "LIVES"} REMAINING`}</small></div>`).join('<i aria-hidden="true">/</i>')}</div></div><section class="pause-drawer"><span class="overlay-kicker">ABROZ COMBAT / TIME OUT</span><h2 id="pause-title">TAKE A<br>BREATHER.</h2><p>Your fight is paused.<br>Step back in when you’re ready.</p><div class="overlay-actions"><button class="overlay-action main-action" data-action="pause"><span>RESUME FIGHT<small>Back to the rooftop</small></span><b aria-hidden="true">↗</b></button><button class="overlay-action" data-action="home"><span>MAIN MENU<small>Leave this match</small></span><b aria-hidden="true">→</b></button></div><span class="pause-key"><kbd>ESC</kbd> RESUME FIGHT</span></section></dialog>`,
    );
    const pauseDialog = document.getElementById("pause") as HTMLDialogElement;
    pauseDialog.showModal();
    pauseDialog.addEventListener("cancel", (event) => {
      event.preventDefault();
      if (paused) pause();
    });
  } else {
    document.getElementById("pause")?.remove();
    input.clear();
  }
}
ui.onAction((action, element) => {
  audio.unlock();
  audio.play("ui");
  switch (action) {
    case "home":
      home();
      break;
    case "back-fighters":
      selection();
      break;
    case "edit-player":
      selectSeat = 0;
      selection();
      break;
    case "local":
    case "training":
    case "online":
      mode = action;
      selectSeat = 0;
      selection();
      break;
    case "characters":
      selection(true);
      break;
    case "settings":
      settings();
      break;
    case "pick": {
      const id = element.dataset.id!;
      if (screen === "roster") { if (archiveId !== id) archiveSkin = undefined; archiveId = id; }
      else { if (selected[selectSeat] !== id) selectedSkins[selectSeat] = resolveSkin(characters[id]); selected[selectSeat] = id; }
      selection(screen === "roster");
      ui.root.querySelector<HTMLButtonElement>(`[data-action="pick"][data-id="${id}"]`)?.focus();
      break;
    }
    case "confirm-fighter":
      if (mode === "local" && selectSeat === 0) {
        selectSeat = 1;
        selection();
      } else stage();
      break;
    case "launch":
      if (mode === "online") lobby();
      else void start();
      break;
    case "create":
      void connect(true);
      break;
    case "join":
      void connect(false);
      break;
    case "pause":
      pause();
      break;
    case "reset":
      simulation.resetPositions();
      break;
    case "debug":
      debug = !debug;
      break;
    case "rematch":
      void start();
      break;
    case "fullscreen":
      if (!document.fullscreenElement)
        void document.documentElement.requestFullscreen().catch(() => {});
      else void document.exitFullscreen();
      break;
    case "bind": {
      cancelBinding?.();
      const player = Number(element.dataset.player), index = Number(element.dataset.index);
      const original = input.bindings[player][index];
      element.textContent = "PRESS KEY";
      const handler = (e: KeyboardEvent) => {
        e.preventDefault();
        e.stopImmediatePropagation();
        if (e.repeat) return;
        if (e.code === "Escape") { cancelBinding?.(); return; }
        if (["F1", "KeyR"].includes(e.code)) { element.textContent = "RESERVED · TRY ANOTHER"; return; }
        input.bindings.forEach(row => row.forEach((key, i) => { if (key === e.code) row[i] = original; }));
        input.bindings[player][index] = e.code;
        input.save();
        cancelBinding?.();
        settings();
      };
      cancelBinding = () => {
        window.removeEventListener("keydown", handler, true);
        element.textContent = original;
        cancelBinding = undefined;
      };
      window.addEventListener("keydown", handler, true);
      break;
    }
  }
});
window.addEventListener("keydown", (e) => {
  if ((e.target as HTMLElement).matches("input,select")) return;
  if (e.code === "F1" && !e.repeat) {
    e.preventDefault();
    debug = !debug;
  }
  if (e.code === "Escape") {
    // Suppress the native dialog cancel for this key after toggling pause.
    e.preventDefault();
    if (!e.repeat) pause();
  }
  if (e.code === "KeyR" && mode === "training" && screen === "fight")
    simulation.resetPositions();
});
window.addEventListener("blur", () => {
  if (screen === "fight" && mode !== "online" && !paused) pause();
});
setInterval(() => {
  if (rollback) network.measurePing();
}, 2000);
function loop(now: number) {
  const elapsed = Math.min(0.1, (now - last) / 1000);
  last = now;
  fps = fps * 0.95 + (1 / Math.max(0.001, elapsed)) * 0.05;
  if (screen === "fight" && !paused) {
    accumulator += elapsed;
    let ticks = 0;
    while (accumulator >= 1 / 60 && ticks++ < 6) {
      if (rollback) {
        rollback.schedule(input.poll(0), (frame, mask) =>
          network.send({ type: "input", frame, mask }),
        );
        if (!rollback.tick()) {
          accumulator = 0;
          break;
        }
        const hashFrame =
          Math.floor(
            Math.min(rollback.confirmed, simulation.state.frame - 1) / 60,
          ) * 60;
        if (hashFrame >= 0 && hashFrame > lastHash) {
          const hash = rollback.confirmedHash(hashFrame);
          if (hash) {
            network.send({ type: "hash", frame: hashFrame, hash });
            lastHash = hashFrame;
          }
        }
        for (const [key, { frame, hash }] of pendingHashes) {
          const local = rollback.confirmedHash(frame);
          if (local) {
            if (local !== hash) rollback.desync = `MISMATCH @ ${frame}`;
            pendingHashes.delete(key);
          }
        }
      } else simulation.step([input.poll(0), input.poll(1)]);
      renderer.consume(
        simulation.events.map((e) => ({
          ...e,
          type:
            characters[simulation.state.fighters[e.player].characterId].effects[
              e.type
            ] ?? e.type,
        })),
      );
      simulation.events.forEach((e) =>
        audio.play(
          characters[simulation.state.fighters[e.player].characterId].sounds[
            e.type
          ] ?? e.type,
        ),
      );
      accumulator -= 1 / 60;
    }
    updateHUD();
  } else accumulator = 0;
  renderer.debug = debug && screen === "fight";
  renderer.draw(
    simulation.state,
    elapsed,
    now / 1000,
    !["fight", "result"].includes(screen),
  );
  requestAnimationFrame(loop);
}
home();
requestAnimationFrame(loop);
