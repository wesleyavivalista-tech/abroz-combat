import { FireEffects } from "./FireEffects.js";
import { worldX, arenaWidth, cameraBounds } from "./StageCoordinates.js";
import * as THREE from "three";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import { type FighterVisual } from "./FighterRenderer.js";
import { createFighterVisual, loadFighterSprites } from "./VisualRegistry.js";
import { StageRenderer } from "./StageRenderer.js";
import { EffectManager } from "./EffectManager.js";
import { characters } from "../../../../packages/game-core/characters/registry.js";
import {
  hurtbox,
  hitboxes,
} from "../../../../packages/game-core/combat/CollisionSystem.js";
import type {
  SimulationSnapshot,
  CombatEvent,
  Box,
} from "../../../../packages/game-core/types.js";
export class SceneRenderer {
  renderer: THREE.WebGLRenderer;
  composer: EffectComposer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(35, 16 / 9, 0.1, 80);
  stage = new StageRenderer();
  effects = new EffectManager();
  fire = new FireEffects();
  fighters: FighterVisual[] = [];
  ids = "";
  ready = this.prepareFighters();
  async prepareFighters(): Promise<void> {
    await loadFighterSprites();
    this.ids = "";
  }
  debug = false;
  shake = 0;
  projectiles: THREE.Mesh[] = [];
  debugBoxes: THREE.LineSegments[] = [];
  shields: THREE.Group[] = [];
  constructor(canvas: HTMLCanvasElement) {
    void this.ready.catch(() => {});
    void this.stage.ready.catch(() => {});
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
    });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.scene.background = new THREE.Color("#6c747e");
    this.scene.fog = new THREE.Fog("#6c747e", 13, 30);
    this.scene.add(
      this.stage.root,
      this.effects.root,
      this.fire.root,
      new THREE.AmbientLight("#c9d4e0", 1.3),
    );
    const key = new THREE.DirectionalLight("#ffe0b4", 2.7);
    key.position.set(-3, 6, 5);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    Object.assign(key.shadow.camera, {
      left: -arenaWidth / 2 - 3,
      right: arenaWidth / 2 + 3,
      top: 8,
      bottom: -8,
    });
    this.scene.add(key);
    const rim = new THREE.DirectionalLight("#b6c9e2", 1.4);
    rim.position.set(3, 4, -4);
    this.scene.add(rim);
    const orange = new THREE.PointLight("#ffd3a1", 6, 16);
    orange.position.set(6, 3, 1);
    this.scene.add(orange);
    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.composer.addPass(
      new UnrealBloomPass(new THREE.Vector2(1280, 720), 0.12, 0.5, 0.85),
    );
    this.composer.addPass(new OutputPass());
    this.camera.position.set(0, 3.4, 12);
    this.camera.lookAt(0, 1.25, 0);
    for (let i = 0; i < 48; i++) {
      const mesh = new THREE.Mesh(
        new THREE.IcosahedronGeometry(0.23, 1),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(2.5, 3.4, 1.3),
          toneMapped: false,
        }),
      );
      const halo = new THREE.Mesh(
        new THREE.SphereGeometry(0.32, 12, 8),
        new THREE.MeshBasicMaterial({
          color: "#b4ed8a",
          transparent: true,
          opacity: 0.22,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
        }),
      );
      mesh.add(halo);
      const orbit = new THREE.Mesh(
        new THREE.TorusGeometry(0.3, 0.018, 6, 28),
        new THREE.MeshBasicMaterial({ color: "#ecffbb", toneMapped: false }),
      );
      orbit.rotation.x = 0.7;
      mesh.add(orbit);
      mesh.visible = false;
      this.scene.add(mesh);
      this.projectiles.push(mesh);
    }
    for (let i = 0; i < 6; i++) {
      const shield = new THREE.Group();
      const shell = new THREE.Mesh(
        new THREE.SphereGeometry(1, 24, 16),
        new THREE.MeshBasicMaterial({
          color: "#a6f3ff",
          transparent: true,
          opacity: 0.12,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
        }),
      );
      shell.scale.set(0.65, 1, 0.42);
      shield.add(shell);
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(1, 0.018, 6, 48),
        new THREE.MeshBasicMaterial({
          color: "#a6f3ff",
          transparent: true,
          opacity: 0.8,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
          toneMapped: false,
        }),
      );
      ring.scale.x = 0.65;
      shield.add(ring);
      shield.visible = false;
      this.scene.add(shield);
      this.shields.push(shield);
    }
    for (let i = 0; i < 42; i++) {
      const mesh = new THREE.LineSegments(
        new THREE.EdgesGeometry(new THREE.BoxGeometry(1, 1, 0.05)),
        new THREE.LineBasicMaterial({ color: "#ff596f", depthTest: false }),
      );
      mesh.renderOrder = 999;
      mesh.visible = false;
      this.scene.add(mesh);
      this.debugBoxes.push(mesh);
    }
    new ResizeObserver(() => this.resize()).observe(canvas.parentElement!);
    this.resize();
  }
  resize(): void {
    const canvas = this.renderer.domElement;
    this.renderer.setSize(
      canvas.parentElement!.clientWidth,
      canvas.parentElement!.clientHeight,
      false,
    );
    this.composer.setSize(
      canvas.parentElement!.clientWidth,
      canvas.parentElement!.clientHeight,
    );
    this.camera.aspect = canvas.clientWidth / canvas.clientHeight;
    this.camera.updateProjectionMatrix();
  }
  consume(events: CombatEvent[]): void {
    events.forEach((e) => {
      this.effects.spawn(e);
      if (e.power >= 3) this.shake = 0.07;
    });
  }
  draw(s: SimulationSnapshot, dt: number, time: number, menu = false): void {
    const ids = s.fighters.map((f, i) => `${f.characterId}:${s.skins[i]}`).join();
    if (ids !== this.ids) {
      this.fighters.forEach((f) => {
        this.scene.remove(f.root);
        if (f.shadow) this.scene.remove(f.shadow);
        f.dispose();
      });
      this.fighters = s.fighters.map((f, i) =>
        createFighterVisual(characters[f.characterId], s.skins[i]),
      );
      this.fighters.forEach((f) => {
        this.scene.add(f.root);
        if (f.shadow) this.scene.add(f.shadow);
      });
      this.ids = ids;
    }
    this.shields.forEach((shield) => (shield.visible = false));
    this.fighters.forEach((visual, i) => {
      const fighter = s.fighters[i];
      visual.update(fighter, time);
      visual.root.visible = !menu && fighter.respawnAt === 0 && fighter.lives > 0;
      if (visual.shadow)
        visual.shadow.visible = visual.root.visible;
      const shield = this.shields[i];
      shield.visible =
        visual.root.visible &&
        s.frame < fighter.invulnerableUntil &&
        s.phase === "fight";
      shield.position.set(worldX(fighter.x), fighter.y / 100 + 0.9, 0.1);
      shield.scale.setScalar(1 + Math.sin(time * 8) * 0.035);
    });
    this.fire.update(s, menu);
    this.stage.update(time);
    this.effects.update(dt);
    const survivors = s.fighters.filter((f) => f.lives > 0);
    const tracked = survivors.length ? survivors : s.fighters;
    const left = Math.min(...tracked.map((f) => f.x));
    const right = Math.max(...tracked.map((f) => f.x));
    const mid = worldX((left + right) / 2);
    const distance = (right - left) / 100;
    const height = Math.max(...tracked.map((f) => f.y)) / 100;
    const targetX = menu
      ? 0
      : Math.max(cameraBounds[0], Math.min(cameraBounds[1], mid));
    const targetZ = menu
      ? 12.8
      : Math.max(
          13.5,
          (distance / 2 + Math.abs(mid - targetX) + 2) /
            (Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2)) *
              this.camera.aspect),
          height * 1.5 + 7,
        );
    const smoothing = 1 - Math.exp(-dt * 5);
    this.camera.position.x += (targetX - this.camera.position.x) * smoothing;
    this.camera.position.z += (targetZ - this.camera.position.z) * smoothing;
    this.camera.position.y = 3.15 + height * 0.18;
    const fog = this.scene.fog as THREE.Fog;
    fog.near = this.camera.position.z + 1;
    fog.far = this.camera.position.z + 18;
    this.camera.lookAt(targetX, (menu ? 1.0 : 2.1) + height * 0.25, 0);
    this.camera.updateMatrixWorld();
    const tags = document.getElementById("player-tags");
    if (tags) {
      const colors = [
        "#c9ec7a",
        "#ffb18e",
        "#7adfff",
        "#dbadff",
        "#ffdf70",
        "#ff83ba",
      ];
      tags.innerHTML = s.fighters
        .map((f, i) => {
          if (f.lives === 0 || f.respawnAt > 0) return "";
          const point = new THREE.Vector3(
            worldX(f.x),
            f.y / 100 + 2.15,
            0,
          ).project(this.camera);
          return `<span class="player-tag" style="left:${(point.x + 1) * 50}%;top:${(1 - point.y) * 50}%;color:${s.teamMatch ? ["#7adfff", "#ff8575"][s.teams[i]] : colors[i]}">P${i + 1}${s.teamMatch ? ` · ${["BLUE", "RED"][s.teams[i]]}` : ""}</span>`;
        })
        .join("");
    }
    this.camera.position.x += Math.sin(time * 91) * this.shake;
    this.shake *= 0.82;
    this.projectiles.forEach((mesh, i) => {
      const p = s.projectiles[i];
      mesh.visible = p.active && !characters[s.fighters[p.owner].characterId].moves[p.move].projectile?.visual;
      if (p.active) {
        mesh.position.set(worldX(p.x), p.y / 100, 0.1);
        mesh.rotation.z = time * 8;
        const superMove = characters[
          s.fighters[p.owner].characterId
        ].superButtons.includes(p.move);
        mesh.scale.set(
          superMove ? 3.2 : 1.7,
          superMove ? 1.4 : 1,
          superMove ? 1.4 : 1,
        );
      }
    });
    this.debugBoxes.forEach((m) => (m.visible = false));
    if (this.debug) {
      let n = 0;
      const show = (b: Box, color: string) => {
        const mesh = this.debugBoxes[n++];
        if (!mesh) return;
        mesh.visible = true;
        mesh.position.set(worldX(b.x + b.w / 2), (b.y + b.h / 2) / 100, 0.6);
        mesh.scale.set(b.w / 100, b.h / 100, 1);
        (mesh.material as THREE.LineBasicMaterial).color.set(color);
      };
      for (const f of s.fighters) {
        if (f.respawnAt > 0 || f.lives === 0) continue;
        show(hurtbox(f), "#79caff");
        show({ x: f.x - 32, y: f.y, w: 64, h: 125 }, "#c9ec7a");
        for (const box of hitboxes(
          f,
          f.move ? characters[f.characterId].moves[f.move] : undefined,
        ))
          show(box, "#ff527a");
      }
    }
    this.composer.render();
  }
}
