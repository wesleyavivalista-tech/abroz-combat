import { TochaRenderer } from "./TochaRenderer.js";
import * as THREE from "three";
import { PixelFighterRenderer } from "./PixelFighterRenderer.js";

import type { CharacterDefinition } from "../../../../packages/game-core/types.js";
import { FighterRenderer, type FighterVisual } from "./FighterRenderer.js";
export type VisualFactory = (definition: CharacterDefinition) => FighterVisual;
const factories = new Map<string, VisualFactory>();
export function registerFighterVisual(
  id: string,
  factory: VisualFactory,
  skin = "original",
): void {
  factories.set(`${id}:${skin}`, factory);
}
export function createFighterVisual(
  definition: CharacterDefinition,
  skin = "original",
): FighterVisual {
  return (
    (factories.get(`${definition.id}:${skin}`) ?? factories.get(`${definition.id}:original`))?.(definition) ??
    new FighterRenderer(definition.color, definition.id === "prototype-b")
  );
}

const skinLoaders = new Map<string, () => Promise<void>>();
/** Register before match loading; the loader decodes assets and registers its factory. */
export function registerSkinLoader(characterId: string, skinId: string, loader: () => Promise<void>): void {
  skinLoaders.set(`${characterId}:${skinId}`, loader);
  loading = undefined;
}
let loading: Promise<void> | undefined;
export function loadFighterSprites(): Promise<void> {
  return loading ??= Promise.all(["prototype-a", "prototype-b"].map(async (id) => {
    const [atlas, movement, crouch] = await Promise.all(["pixel", "movement", "crouch"].map(async (kind) => {
      const texture = await new THREE.TextureLoader().loadAsync(kind === "crouch" ? "/art/crouch-attacks-v1.png" : `/art/${id}-${kind}-v1.png`);
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.magFilter = THREE.NearestFilter;
      texture.minFilter = THREE.NearestFilter;
      texture.generateMipmaps = false;
      return texture;
    }));
    registerFighterVisual(id, (definition) => new PixelFighterRenderer(definition, atlas, movement, crouch));
  })).then(async () => {
    const atlases = await Promise.all([1, 2].map(async n => {
      const t = await new THREE.TextureLoader().loadAsync(`/art/tocha/skin-${n}-atlas.png`);
      t.colorSpace = THREE.SRGBColorSpace; t.magFilter = t.minFilter = THREE.NearestFilter; t.generateMipmaps = false; return t;
    }));
    registerFighterVisual("tocha", def => new TochaRenderer(def, atlases, 0));
    registerFighterVisual("tocha", def => new TochaRenderer(def, atlases, 1), "shirtless");
    await Promise.all([...skinLoaders.values()].map(load => load()));
  }).catch(error => { loading = undefined; throw error; });
}
