import { trainingRoom } from "../../../../packages/game-core/stages/registry.js";

export const arenaWidth = trainingRoom.width / 100;
export const worldX = (x: number): number => x / 100 - arenaWidth / 2;
export const cameraBounds = trainingRoom.cameraBounds.map(worldX);
