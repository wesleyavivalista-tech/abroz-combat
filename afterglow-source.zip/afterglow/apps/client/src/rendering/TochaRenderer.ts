import * as THREE from "three";
import type { CharacterDefinition, Fighter } from "../../../../packages/game-core/types.js";
import type { FighterVisual } from "./FighterRenderer.js";
import { worldX } from "./StageCoordinates.js";
import { surfaceBelow } from "../../../../packages/game-core/simulation/StageCollision.js";
import { trainingRoom } from "../../../../packages/game-core/stages/registry.js";
import { tochaFrames } from "./TochaAtlas.js";
export function tochaPose(f: Fighter, def: CharacterDefinition): number {
  if (f.move) {
    const m = def.moves[f.move];
    if (f.move === "satan") return f.moveFrame < m.startupFrames ? 16 + Math.floor(f.moveFrame / 9) % 2 : 13;
    if (f.move === "ignite") return 15;
    if (f.move === "pentagram") return 14;
    if (f.moveFrame < Math.max(2, m.startupFrames - 5)) return f.state === "CrouchingAttack" ? 18 : f.state === "AirAttack" ? 21 : 0;
    if (f.moveFrame > m.startupFrames + m.activeFrames + 7) return f.state === "CrouchingAttack" ? 18 : f.state === "AirAttack" ? 21 : 0;
    return ({jab: 8, cross: 9, finisher: 10, heavy: 11, double: 12, fireball: 13, crouch: 20, air: 10} as Record<string, number>)[f.move] ?? 0;
  }
  if (["KO", "Knockdown", "Respawning"].includes(f.state)) return 23;
  if (f.state.includes("HitStun")) return 22;
  if (["Crouch", "BlockCrouching", "GetUp"].includes(f.state)) return 18;
  if (["Jump", "Fall"].includes(f.state)) return 21;
  if (f.state.startsWith("Dash")) return 5 + Math.floor(f.stateFrame / 3) % 3;
  if (f.state.startsWith("Walk")) {
    const cycle = Math.floor(Math.abs(f.x) / 18) % 4;
    return 1 + (f.state === "WalkBackward" ? 3 - cycle : cycle);
  }
  return f.state === "MatchWin" ? 16 : 0;
}
export class TochaRenderer implements FighterVisual {
  root = new THREE.Group();
  shadow: THREE.Mesh;
  private textures: THREE.Texture[];
  private sprite: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>;
  constructor(private def: CharacterDefinition, atlases: THREE.Texture[], private skin: number) {
    this.textures = atlases.map(t => {const clone = t.clone(); clone.needsUpdate = true; return clone;});
    this.sprite = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({map: this.textures[skin], transparent: true, alphaTest: .2, toneMapped: false, side: THREE.DoubleSide}));
    this.root.add(this.sprite);
    this.shadow = new THREE.Mesh(new THREE.CircleGeometry(.5, 24), new THREE.MeshBasicMaterial({color: 0x15121a, transparent: true, opacity: .22, depthWrite: false}));
    this.shadow.rotation.x = -Math.PI / 2;
  }
  update(f: Fighter, time: number): void {
    const skin = f.move === "satan" ? 1 : this.skin;
    const pose = tochaPose(f, this.def);
    const frames = tochaFrames[skin ? "2" : "1"];
    const [left, top, right, bottom] = frames[pose];
    const w = right - left + 2, h = bottom - top + 2;
    const texture = this.textures[skin];
    texture.repeat.set(w / 1536, h / 1024);
    texture.offset.set((left - 1) / 1536, 1 - (bottom + 1) / 1024);
    this.sprite.material.map = texture;
    const scale = 1.74 / (frames[0][3] - frames[0][1]);
    // Body pivots stay behind extended hands/feet, avoiding pose-to-pose sliding.
    const pivotFraction = [0.50,.5,.5,.5,.5,.52,.52,.52,.37,.37,.28,.27,.36,.33,.47,.5,.5,.5,.5,.31,.26,.5,.52,.5][pose];
    const pivot = left + (right - left) * pivotFraction;
    this.sprite.scale.set(w * scale, h * scale, 1);
    const breathe = !f.move && f.state === "Idle" ? Math.sin(time * 3) * .012 : 0;
    this.sprite.position.set(((left + right) / 2 - pivot) * scale, h * scale / 2 + breathe, 0);
    this.root.position.set(worldX(f.x), f.y / 100, .09);
    this.root.scale.x = f.facing;
    const floor = surfaceBelow(trainingRoom, f.x, f.y);
    this.shadow.position.set(worldX(f.x), floor / 100 + .02, 0);
    const size = Math.max(.4, 1 - (f.y - floor) / 700);
    this.shadow.scale.set(size * 1.2, size * .5, 1);
  }
  dispose(): void {
    this.textures.forEach(t => t.dispose());
    this.sprite.geometry.dispose(); this.sprite.material.dispose();
    this.shadow.geometry.dispose(); (this.shadow.material as THREE.Material).dispose();
  }
}
