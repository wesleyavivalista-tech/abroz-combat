import * as THREE from "three";
import type { SimulationSnapshot } from "../../../../packages/game-core/types.js";
import { characters } from "../../../../packages/game-core/characters/registry.js";
import { worldX } from "./StageCoordinates.js";
function flame() {
  return new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, toneMapped: false, side: THREE.DoubleSide,
    uniforms: { clock: {value: 0}, strength: {value: .8} },
    vertexShader: `varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
    fragmentShader: `varying vec2 vUv; uniform float clock; uniform float strength;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}
      void main(){vec2 uv=floor(vUv*72.)/72.;float y=uv.y;
        float n=noise(vec2(uv.x*9.,y*7.-clock*4.))*.65+noise(vec2(uv.x*21.,y*17.-clock*7.))*.35;
        float edge=abs(uv.x-.5+sin(y*11.-clock*5.)*.035);
        float height=.58+.26*sin(uv.x*23.+clock*2.)+.13*sin(uv.x*41.-clock*3.);
        float density=(1.-y)*.72-edge*1.05+(n-.4)*.5;
        float shape=smoothstep(.06,.24,density)*smoothstep(height+.18,height-.12,y)*smoothstep(0.,.07,y);
        float core=clamp(density*1.8-y*.25,0.,1.);
        vec3 color=mix(vec3(1.,.11,.008),vec3(1.,.85,.26),core);
        gl_FragColor=vec4(color*1.35,shape*strength); }
    `,
  }));
}
function sigil() {
  const root = new THREE.Group();
  const material = new THREE.LineBasicMaterial({color: "#ff963c", transparent: true, opacity: .95, toneMapped: false, depthWrite: false});
  const circle = Array.from({length: 64}, (_, i) => new THREE.Vector3(Math.cos(i * Math.PI / 32), Math.sin(i * Math.PI / 32), 0));
  root.add(new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(circle), material));
  const points = Array.from({length: 6}, (_, i) => {const angle = -Math.PI / 2 + i * Math.PI * 4 / 5; return new THREE.Vector3(Math.cos(angle) * .9, Math.sin(angle) * .9, 0);});
  root.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), material));
  const inner = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(circle.map(v => v.clone().multiplyScalar(.94))), material);
  root.add(inner); root.visible = false;
  return root;
}
/** Fixed pools: status visuals read only the restored simulation snapshot. */
export class FireEffects {
  root = new THREE.Group();
  private bodies = Array.from({length: 6}, flame);
  private limbs = Array.from({length: 12}, flame);
  private casts = Array.from({length: 6}, sigil);
  private traps = Array.from({length: 48}, sigil);
  private shots = Array.from({length: 48}, () => {const group = new THREE.Group(); group.add(flame(), sigil()); return group;});
  constructor() { this.root.add(...this.bodies, ...this.limbs, ...this.casts, ...this.traps, ...this.shots); }
  update(s: SimulationSnapshot, menu: boolean): void {
    this.root.visible = !menu;
    const time = s.frame / 60;
    const showFlame = (mesh: ReturnType<typeof flame>, x: number, y: number, w: number, h: number, seed: number) => {
      mesh.visible = true; mesh.position.set(x, y, .22); mesh.scale.set(w, h, 1); mesh.material.uniforms.clock.value = time + seed;
    };
    this.bodies.forEach(m => m.visible = false); this.limbs.forEach(m => m.visible = false);
    this.casts.forEach(m => m.visible = false); this.traps.forEach(m => m.visible = false);
    s.fighters.forEach((f, i) => {
      if (!f.lives || f.respawnAt || s.phase !== "fight") return;
      const x = worldX(f.x), y = f.y / 100;
      const aura = f.onFireUntil > s.frame;
      if (aura || f.burnUntil >= s.frame && f.burnUntil > 0) {
        showFlame(this.bodies[i], x, y + 1.0, aura ? 1.6 : 1.05, aura ? 2.4 : 2.1, i);
        this.bodies[i].material.uniforms.strength.value = aura ? .5 : .4;
      }
      if (f.characterId !== "tocha" || !f.move) return;
      const m = characters.tocha.moves[f.move];
      if (f.move === "satan" && f.moveFrame < m.startupFrames) {
        const g = this.casts[i]; g.visible = true; g.position.set(x, y + 1.8, .25);
        g.scale.setScalar(.3 + .6 * Math.min(1, f.moveFrame / 45)); g.rotation.z = Math.sin(time * 6) * .06;
      }
      if (["jab", "cross", "finisher", "heavy", "double", "crouch", "air", "fireball"].includes(f.move) && f.moveFrame >= Math.max(0, m.startupFrames - 5) && f.moveFrame < m.startupFrames + m.activeFrames + 7) {
        const kick = ["finisher", "heavy", "crouch", "air"].includes(f.move);
        const height = f.move === "crouch" ? .3 : f.move === "heavy" ? 1.5 : kick ? 1.05 : 1.3;
        const reach = kick ? .95 : .82;
        showFlame(this.limbs[i * 2], x + f.facing * reach, y + height, .65, .8, i);
        if (f.move === "double" || f.move === "fireball") showFlame(this.limbs[i * 2 + 1], x + f.facing * .6, y + 1.05, .6, .8, i + 1);
      }
    });
    s.hazards.forEach((h, i) => {
      const g = this.traps[i]; if (!g) return;
      g.visible = true; g.position.set(worldX(h.x), h.y / 100 + .025, .05);
      g.rotation.x = -Math.PI / 2; g.scale.setScalar(1.2);
      g.children.forEach(c => ((c as THREE.Line).material as THREE.LineBasicMaterial).opacity = Math.min(1, (h.expiresAt - s.frame) / 30) * (.8 + Math.sin(time * 8) * .15));
    });
    this.shots.forEach((g, i) => {
      const p = s.projectiles[i]; const spec = p.active ? characters[s.fighters[p.owner].characterId].moves[p.move].projectile : undefined;
      g.visible = !!spec?.visual; if (!g.visible) return;
      g.position.set(worldX(p.x), p.y / 100, .2);
      const f = g.children[0] as ReturnType<typeof flame>, star = g.children[1];
      f.visible = spec!.visual === "fire"; star.visible = !f.visible;
      f.rotation.z = p.vx < 0 ? -Math.PI / 2 : Math.PI / 2;
      f.scale.set(.8, 1.2, 1); f.material.uniforms.clock.value = time;
      star.scale.setScalar(.7); star.rotation.z = time * 3;
    });
  }
}
