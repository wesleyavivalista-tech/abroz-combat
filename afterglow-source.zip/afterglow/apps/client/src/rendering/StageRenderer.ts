import * as THREE from "three";
import { trainingRoom } from "../../../../packages/game-core/stages/registry.js";
import { arenaWidth, worldX } from "./StageCoordinates.js";

/** A present-day rooftop court; all decoration stays outside collision logic. */
export class StageRenderer {
  root = new THREE.Group();
  ready: Promise<void>;
  constructor() {
    this.ready = new THREE.TextureLoader().loadAsync("/art/rooftop-city-v1.png").then(texture => {
      texture.colorSpace = THREE.SRGBColorSpace;
      const skyline = new THREE.Mesh(new THREE.PlaneGeometry(52, 29.25),
        new THREE.MeshBasicMaterial({ map: texture, fog: false, toneMapped: false }));
      skyline.position.set(0, 6, -9);
      this.root.add(skyline);
    });
    const concrete = new THREE.MeshStandardMaterial({ color: "#85827b", roughness: 0.95 });
    const steel = new THREE.MeshStandardMaterial({ color: "#333b43", roughness: 0.7, metalness: 0.25 });
    const white = new THREE.MeshStandardMaterial({ color: "#e7dfca", roughness: 0.9 });
    const terracotta = new THREE.MeshStandardMaterial({ color: "#b66043", roughness: 0.9 });
    const box = (x: number, y: number, z: number, w: number, h: number, d: number, material: THREE.Material) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
      mesh.position.set(x, y, z); mesh.receiveShadow = true; mesh.castShadow = true;
      this.root.add(mesh); return mesh;
    };
    const canvas = document.createElement("canvas"); canvas.width = canvas.height = 512;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#60696a"; ctx.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 8000; i++) {
      ctx.fillStyle = i % 2 ? "#dcd6c316" : "#151d211c";
      ctx.fillRect((i * 317) % 512, (i * 97) % 512, 1 + i % 3, 1);
    }
    ctx.strokeStyle = "#232e3244"; ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, 510, 510);
    const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping; texture.repeat.set(12, 3);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(50, 9),
      new THREE.MeshStandardMaterial({map: texture, roughness: 0.96}));
    floor.rotation.x = -Math.PI / 2; floor.position.y = -0.01; floor.receiveShadow = true; this.root.add(floor);
    box(0, -1.6, 3.5, 50, 3.1, 1, concrete);
    box(0, -0.12, 3.4, 50, 0.24, 1.1, concrete);
    for (const z of [-1.6, 1.6]) box(0, 0.005, z, arenaWidth, 0.012, 0.05, white);
    for (const x of [-12, 0, 12]) box(x, 0.005, 0, 0.055, 0.012, 3.2, white);
    const courtRing = new THREE.Mesh(new THREE.RingGeometry(1.35, 1.4, 64), white);
    courtRing.rotation.x = -Math.PI / 2; courtRing.position.y = 0.009; this.root.add(courtRing);
    // Rear parapet and chain-link fence remain behind the fighters.
    box(0, 0.28, -3.5, 50, 0.56, 0.35, concrete);
    for (let x = -24; x <= 24; x += 2) box(x, 1.2, -3.5, 0.045, 1.8, 0.045, steel);
    box(0, 2.1, -3.5, 50, 0.04, 0.04, steel);
    const fenceVertices: number[] = [];
    for (let x = -25; x < 25; x += 0.25) {
      fenceVertices.push(x, 0.55, -3.5, x + 1.55, 2.1, -3.5);
      fenceVertices.push(x, 2.1, -3.5, x + 1.55, 0.55, -3.5);
    }
    const fence = new THREE.BufferGeometry(); fence.setAttribute("position", new THREE.Float32BufferAttribute(fenceVertices, 3));
    this.root.add(new THREE.LineSegments(fence, new THREE.LineBasicMaterial({color: "#738083", transparent: true, opacity: 0.32})));
    // Rooftop practice decks, with unchanged playable top surfaces.
    for (const platform of trainingRoom.platforms ?? []) {
      const x = worldX(platform.x + platform.width / 2), y = platform.y / 100, width = platform.width / 100;
      box(x, y - 0.12, 0, width, 0.24, 1.5, concrete);
      box(x, y - 0.055, 0.76, width, 0.065, 0.035, terracotta);
      box(x, y - 0.21, 0.76, width, 0.045, 0.035, white);
      for (const dx of [-width / 2 + 0.25, width / 2 - 0.25]) {
        box(x + dx, y / 2 - 0.12, -0.68, 0.15, y - 0.24, 0.15, steel);
        box(x + dx, 0.06, -0.68, 0.42, 0.12, 0.42, concrete);
      }
      for (let dx = -width / 2 + 0.1; dx < width / 2; dx += 0.6)
        box(x + dx, y - 0.14, 0.785, 0.025, 0.025, 0.01, steel);
    }
    // Everyday rooftop props beyond the combat plane.
    for (const x of [-10, 10]) {
      box(x, 0.62, -2.9, 1.4, 1.1, 0.8, concrete);
      for (let y = 0.22; y < 1.1; y += 0.1) box(x, y, -2.48, 1.18, 0.035, 0.025, steel);
      box(x, 1.2, -2.9, 1.5, 0.08, 0.9, steel);
    }
    for (const x of [-13, 13]) {
      box(x, 3.5, -2, 0.1, 7, 0.1, steel);
      box(x, 6.85, -1.9, 0.75, 0.2, 0.3, steel);
      box(x, 6.79, -1.72, 0.63, 0.1, 0.04, white);
    }
  }
  update(_time: number): void { /* The rooftop is intentionally still. */ }
}
