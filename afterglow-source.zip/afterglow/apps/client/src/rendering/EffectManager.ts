import { worldX } from "./StageCoordinates.js";
import * as THREE from "three";
import type { CombatEvent } from "../../../../packages/game-core/types.js";
interface Particle {
  mesh: THREE.Mesh;
  life: number;
  duration: number;
  vx: number;
  vy: number;
  vz: number;
}
interface Burst {
  mesh: THREE.Mesh;
  life: number;
  power: number;
}
export class EffectManager {
  root = new THREE.Group();
  pool: Particle[] = [];
  bursts: Burst[] = [];
  constructor() {
    const geometry = new THREE.OctahedronGeometry(0.045);
    for (let i = 0; i < 180; i++) {
      const mesh = new THREE.Mesh(
        geometry,
        new THREE.MeshBasicMaterial({
          color: "#e4ffb4",
          transparent: true,
          depthWrite: false,
          toneMapped: false,
          blending: THREE.AdditiveBlending,
        }),
      );
      mesh.visible = false;
      this.root.add(mesh);
      this.pool.push({ mesh, life: 0, duration: 0, vx: 0, vy: 0, vz: 0 });
    }
    for (let i = 0; i < 12; i++) {
      const mesh = new THREE.Mesh(
        new THREE.RingGeometry(0.36, 0.4, 40),
        new THREE.MeshBasicMaterial({
          color: "#e9ffd0",
          transparent: true,
          depthWrite: false,
          toneMapped: false,
          side: THREE.DoubleSide,
          blending: THREE.AdditiveBlending,
        }),
      );
      mesh.visible = false;
      this.root.add(mesh);
      this.bursts.push({ mesh, life: 0, power: 1 });
    }
  }
  spawn(event: CombatEvent): void {
    if (event.type === "attack") return;
    const dust = event.type.includes("dust");
    const count = dust ? 9 : 14 + event.power * 5;
    if (!dust) {
      const burst = this.bursts.find((b) => b.life <= 0);
      if (burst) {
        burst.life = 0.22;
        burst.power = event.power;
        burst.mesh.position.set(worldX(event.x), event.y / 100, 0.4);
        burst.mesh.visible = true;
        burst.mesh.scale.setScalar(0.2);
        (burst.mesh.material as THREE.MeshBasicMaterial).color.set(
          event.type === "block" ? "#a5eaff" : "#fff3ad",
        );
      }
    }
    let n = 0;
    for (const p of this.pool) {
      if (p.life > 0) continue;
      p.life = p.duration = dust ? 0.5 : 0.28;
      p.mesh.visible = true;
      p.mesh.position.set(worldX(event.x), dust ? Math.max(0.08, event.y / 100 - 0.85) : event.y / 100, 0.3);
      const angle = n * 2.399;
      p.vx = Math.cos(angle) * (2 + event.power);
      p.vy = Math.sin(angle) * (2 + event.power) + (dust ? 1 : 0);
      p.vz = Math.sin(n) * 0.5;
      p.mesh.rotation.z = angle;
      p.mesh.scale.set(dust ? 3 : 7, dust ? 1.1 : 0.3, 1);
      (p.mesh.material as THREE.MeshBasicMaterial).color.set(
        event.type === "fire-hit" ? "#ff7530" : event.type === "block" ? "#95e8ff" : dust ? "#b5a18b" : "#fff1ac",
      );
      if (++n >= count) break;
    }
  }
  update(dt: number): void {
    for (const p of this.pool) {
      if (p.life <= 0) continue;
      p.life -= dt;
      p.mesh.visible = p.life > 0;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      p.vy -= 4 * dt;
      (p.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(
        0,
        p.life / p.duration,
      );
    }
    for (const b of this.bursts) {
      if (b.life <= 0) continue;
      b.life -= dt;
      b.mesh.visible = b.life > 0;
      b.mesh.scale.setScalar(0.25 + (1 - b.life / 0.22) * b.power * 0.9);
      (b.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(
        0,
        b.life / 0.22,
      );
    }
  }
}
