import { Button } from "../../../../packages/game-core/types.js";
export const actions = [
  "Left",
  "Right",
  "Up",
  "Down",
  "Combo attack",
  "Heavy attack",
  "Attack 3",
  "Special 1",
  "Special 2",
  "Super 1",
  "Super 2",
] as const;
const bits = [
  Button.Left,
  Button.Right,
  Button.Up,
  Button.Down,
  Button.Light,
  Button.Medium,
  Button.Heavy,
  Button.Special,
  Button.Special2,
  Button.Super1,
  Button.Super2,
];
export class InputManager {
  keys = new Set<string>();
  pending = new Set<string>();
  bindings = [
    [
      "KeyA",
      "KeyD",
      "KeyW",
      "KeyS",
      "KeyJ",
      "KeyK",
      "KeyL",
      "KeyI",
      "KeyU",
      "KeyO",
      "KeyP",
    ],
    [
      "ArrowLeft",
      "ArrowRight",
      "ArrowUp",
      "ArrowDown",
      "Digit1",
      "Digit2",
      "Digit3",
      "Digit0",
      "Digit9",
      "Digit7",
      "Digit8",
    ],
  ];
  gamepadButtons = [0, 2, 1, 3, 5, 6, 7];
  enabled = true;
  constructor() {
    try {
      const saved = JSON.parse(
        localStorage.getItem("afterglow-controls") ?? "null",
      );
      if (saved?.bindings?.length === 2)
        this.bindings = this.bindings.map((row, p) =>
          row.map((key, i) =>
            typeof saved.bindings[p]?.[i] === "string"
              ? saved.bindings[p][i]
              : key,
          ),
        );
      if (Array.isArray(saved?.gamepadButtons))
        this.gamepadButtons = this.gamepadButtons.map((button, i) =>
          Number.isInteger(saved.gamepadButtons[i]) && saved.gamepadButtons[i] >= 0 && saved.gamepadButtons[i] < 16
            ? saved.gamepadButtons[i]
            : button,
        );
    } catch {
      /* Defaults remain available. */
    }
    window.addEventListener("keydown", (e) => {
      if ((e.target as HTMLElement).matches("input,select,textarea")) return;
      if (this.enabled && this.bindings.flat().includes(e.code))
        e.preventDefault();
      this.keys.add(e.code);
      if (this.enabled) this.pending.add(e.code);
    });
    window.addEventListener("keyup", (e) => this.keys.delete(e.code));
    window.addEventListener("blur", () => this.clear());
  }
  poll(player: number): number {
    if (!this.enabled) return 0;
    let mask = 0;
    this.bindings[player].forEach((key, i) => {
      if (this.keys.has(key) || this.pending.has(key)) mask |= bits[i];
      this.pending.delete(key);
    });
    const pad = navigator.getGamepads?.()[player];
    if (pad) {
      if (pad.axes[0] < -0.3 || pad.buttons[14]?.pressed) mask |= Button.Left;
      if (pad.axes[0] > 0.3 || pad.buttons[15]?.pressed) mask |= Button.Right;
      if (pad.axes[1] < -0.3 || pad.buttons[12]?.pressed) mask |= Button.Up;
      if (pad.axes[1] > 0.3 || pad.buttons[13]?.pressed) mask |= Button.Down;
      this.gamepadButtons.forEach((button, i) => {
        if (pad.buttons[button]?.pressed) mask |= bits[i + 4];
      });
    }
    return mask;
  }
  clear(): void {
    this.keys.clear();
    this.pending.clear();
  }
  save(): void {
    try { localStorage.setItem(
      "afterglow-controls",
      JSON.stringify({
        bindings: this.bindings,
        gamepadButtons: this.gamepadButtons,
      }),
    ); } catch { /* Controls still work when browser storage is unavailable. */ }
  }
}
