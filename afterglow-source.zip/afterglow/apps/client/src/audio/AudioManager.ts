export class AudioManager {
  context: AudioContext | null = null;
  master = 0.35;
  music = 0.15;
  sound = 0.65;
  private drone: GainNode | null = null;
  unlock(): void {
    if (!this.context) {
      this.context = new AudioContext();
      this.drone = this.context.createGain();
      this.drone.connect(this.context.destination);
      for (const frequency of [55, 82.4, 110]) {
        const o = this.context.createOscillator();
        o.type = "sine";
        o.frequency.value = frequency;
        o.connect(this.drone);
        o.start();
      }
    }
    void this.context.resume();
    this.update();
  }
  update(): void {
    if (this.drone && this.context)
      this.drone.gain.setTargetAtTime(
        this.master * this.music * 0.1,
        this.context.currentTime,
        0.2,
      );
  }
  play(kind: string): void {
    const c = this.context;
    if (!c || c.state !== "running") return;
    if (kind === "metal") {
      for (const frequency of [82.4, 123.5, 164.8]) {
        const osc = c.createOscillator(), gain = c.createGain();
        osc.type = "sawtooth"; osc.frequency.value = frequency; osc.connect(gain); gain.connect(c.destination);
        gain.gain.setValueAtTime(this.master * this.sound * .035, c.currentTime);
        gain.gain.exponentialRampToValueAtTime(.001, c.currentTime + .8);
        osc.start(); osc.stop(c.currentTime + .81);
      }
      return;
    }
    const o = c.createOscillator(),
      g = c.createGain();
    o.connect(g);
    g.connect(c.destination);
    const hit = kind.includes("hit") || kind === "counter" || kind === "ko";
    o.type = hit ? "sawtooth" : "sine";
    o.frequency.setValueAtTime(
      hit ? 160 : kind === "block" ? 650 : kind === "projectile" ? 420 : 280,
      c.currentTime,
    );
    o.frequency.exponentialRampToValueAtTime(
      hit ? 35 : 100,
      c.currentTime + 0.12,
    );
    g.gain.setValueAtTime(
      this.master * this.sound * (hit ? 0.16 : 0.07),
      c.currentTime,
    );
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.16);
    o.start();
    o.stop(c.currentTime + 0.17);
  }
}
