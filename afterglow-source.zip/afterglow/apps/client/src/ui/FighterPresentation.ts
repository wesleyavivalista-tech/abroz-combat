import { characters } from "../../../../packages/game-core/characters/registry.js";
export interface FighterPresentation {
  portrait: string;
  skins?: Record<string, { portrait: string; facing?: "left" | "right" }>;
  style: string;
  /** Direction the original portrait is looking. */
  facing: "left" | "right";
}
const presentations: Record<string, FighterPresentation> = {
  tocha: {portrait: "/art/tocha/skin-1-portrait-v2.png", style: "FIRE & HEAVY METAL", facing: "right", skins: {shirtless: {portrait: "/art/tocha/skin-2-portrait-v2.png"}}},
  "prototype-a": { portrait: "/art/prototype-a-cutout-v1.png", style: "PRECISION & RANGE", facing: "right" },
  "prototype-b": { portrait: "/art/prototype-b-cutout-v1.png", style: "PRESSURE & POWER", facing: "left" },
};
export function registerFighterPresentation(id: string, presentation: FighterPresentation): void {
  presentations[id] = presentation;
}
export function fighterPresentation(id: string, skin?: string): FighterPresentation {
  const base = presentations[id] ?? { portrait: "/art/fighter-placeholder.svg", style: characters[id]?.description ?? "FIGHTER", facing: "right" as const };
  const variant = skin ? base.skins?.[skin] : undefined;
  return variant ? { ...base, ...variant } : base;
}
export function escapeMarkup(value: string): string {
  return value.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}
