import { basicAttacks } from "../../../../packages/game-core/characters/common.js";
import { fighterSkins } from "../../../../packages/game-core/characters/skins.js";
import { fighterPresentation, escapeMarkup } from "./FighterPresentation.js";
import { characters } from "../../../../packages/game-core/characters/registry.js";

export type MenuMode = "local" | "online" | "training";
const modes: Record<MenuMode, { name: string; title: string; detail: string; count: string; cta: string }> = {
  local: { name: "VERSUS", title: "Settle it on the rooftop.", detail: "Two players. One screen. Pick your fighters and go head to head.", count: "2 PLAYERS / SAME DEVICE", cta: "CHOOSE FIGHTERS" },
  online: { name: "ONLINE", title: "Bring the whole crew.", detail: "Create a private room for up to six fighters. Last one standing wins.", count: "2–6 PLAYERS / PRIVATE ROOM", cta: "CHOOSE YOUR FIGHTER" },
  training: { name: "TRAINING", title: "Make every move yours.", detail: "Practice your combos, specials and movement against a training dummy.", count: "SOLO / FREE PRACTICE", cta: "ENTER TRAINING" },
};
const art = (id: string, skin?: string) => escapeMarkup(fighterPresentation(id, skin).portrait);
const moveList = (id: string, type: "specialButtons" | "superButtons") => {
  return characters[id][type].map(move => escapeMarkup(characters[id].moves[move].displayName ?? move.replaceAll("-", " ").toUpperCase())).join(" / ");
};

export function homeScreen(): string {
  return `<main class="ac-home">
    <div class="ac-home-atmosphere" aria-hidden="true"></div>
    <div class="ac-home-cast" aria-hidden="true"><img class="cast-vector" src="${art("prototype-a")}" alt=""><img class="cast-brut" src="${art("prototype-b")}" alt=""></div>
    <section class="ac-title"><h1 class="ac-custom-wordmark"><img src="/art/abroz-combat-wordmark-v2.svg" alt="Abroz Combat"></h1><p>Three lives. One survivor.</p></section>
    <div class="ac-cast-label cast-label-left"><span>PRECISION / 01</span><strong>VECTOR</strong></div><div class="ac-cast-label cast-label-right"><span>POWER / 02</span><strong>BRUT</strong></div>
    <nav class="ac-direct-menu" aria-label="Main menu">
      ${(Object.keys(modes) as MenuMode[]).map((id)=>`<button class="ac-menu-ticket ticket-${id}" data-action="${id}" aria-label="${modes[id].name}"><span class="ticket-content"><small>${modes[id].count}</small><strong>${modes[id].name}</strong><span>${id === "local" ? "Go head to head" : id === "online" ? "Bring your crew" : "Perfect your moves"}</span></span><b aria-hidden="true">↗</b></button>`).join("")}
      <button class="ac-menu-ticket ticket-roster" data-action="characters" aria-label="FIGHTERS"><span class="ticket-content"><small>ROSTER / MOVE LISTS</small><strong>FIGHTERS</strong><span>Find your fighting style</span></span><b aria-hidden="true">↗</b></button>
    </nav>
  </main>`;
}

export function selectionScreen(mode: MenuMode, selected: readonly string[], selectSeat: number, roster: boolean, archiveId: string, skins: readonly string[] = [], archiveSkin?: string): string {
  const activeId = roster ? archiveId : selected[selectSeat];
  const active = characters[activeId];
  const opponentPreview = Object.keys(characters).find(id => id !== activeId) ?? activeId;
  const seats = roster ? [activeId, opponentPreview] : mode === "online" ? [selected[0], opponentPreview] : selected;
  const activeSeat = roster ? 0 : selectSeat;
  const modeName = roster ? "FIGHTER ARCHIVE" : modes[mode].name;
  const side = (id: string, index: number) => {
    const c = characters[id];
    const skin = roster ? (index === 0 ? archiveSkin : undefined) : skins[index];
    const isUnknown = mode === "online" && index === 1 && !roster;
    const label = roster ? (index === 0 ? "IN FOCUS" : "THE COMPETITION") : mode === "online" ? (index === 0 ? "YOUR FIGHTER" : "YOUR RIVALS") : mode === "training" ? (index === 0 ? "YOUR FIGHTER" : "TRAINING DUMMY") : `PLAYER 0${index + 1}`;
    const status = roster ? (index === 0 ? "ROSTER PREVIEW" : "ROSTER PREVIEW") : isUnknown ? "DECIDED IN THE ROOM" : mode === "training" && index === 1 ? "PRACTICE PARTNER" : index === activeSeat ? "SELECTING" : mode === "local" && selectSeat === 1 && index === 0 ? "LOCKED IN" : "UP NEXT";
    const mirror = fighterPresentation(id, skin).facing !== (index === 0 ? "right" : "left");
    return `<section class="ac-faceoff-side side-${index} ${index === activeSeat ? "is-selecting" : ""} ${isUnknown ? "is-unknown" : ""}" aria-label="${label}">
      <div class="ac-player-flag"><span>${label}</span><b>${status}</b></div>
      <img class="ac-faceoff-art ${mirror ? "is-mirrored" : ""}" src="${art(id, skin)}" alt="${isUnknown ? "Opponent silhouette" : c.displayName}">
      <div class="ac-fighter-identity"><span>${isUnknown ? "FREE-FOR-ALL / 2v2 / 3v3" : escapeMarkup(fighterPresentation(id).style)}</span><h3>${isUnknown ? "WHO’S NEXT?" : c.displayName}</h3>${mode === "local" && selectSeat === 1 && index === 0 && !roster ? '<button class="ac-edit-player" data-action="edit-player">CHANGE FIGHTER</button>' : ""}</div>
    </section>`;
  };
  return `<main class="ac-selection">
    <div class="ac-selection-heading"><span>${modeName}</span><h2>${roster ? "MEET YOUR COMPETITION" : "SELECT YOUR FIGHTER"}</h2>${roster ? "" : '<div class="ac-steps"><b>01 FIGHTERS</b><span>02 ARENA</span><span>03 FIGHT</span></div>'}</div>
    <div class="ac-faceoff">${seats.map(side).join("")}<div class="ac-versus" aria-hidden="true"><span>VS</span><i></i></div></div>
    <section class="ac-selection-console">
      <div class="ac-move-card"><span>${active.displayName} / MOVE LIST</span><dl><div><dt>BASICS</dt><dd>${[basicAttacks(active).chain.map(id => active.moves[id].displayName ?? id).join(" → "), active.moves[basicAttacks(active).heavy].displayName ?? "Heavy", active.moves[basicAttacks(active).kick].displayName ?? "Kick"].map(escapeMarkup).join(" / ")}</dd></div><div><dt>SPECIALS</dt><dd>${moveList(activeId,"specialButtons")}</dd></div><div><dt>SUPERS</dt><dd>${moveList(activeId,"superButtons")}</dd></div></dl><label class="ac-skin-picker">SKIN<select id="fighter-skin" aria-label="Fighter skin" ${fighterSkins(active).length === 1 ? "disabled" : ""}>${fighterSkins(active).map((skin, index) => `<option value="${skin.id}" ${skin.id === (roster ? archiveSkin : skins[activeSeat]) || (!(roster ? archiveSkin : skins[activeSeat]) && index === 0) ? "selected" : ""}>${escapeMarkup(skin.name)}</option>`).join("")}</select><small>${fighterSkins(active).length} ${fighterSkins(active).length === 1 ? "look" : "looks"} · Same moves</small></label></div>
      <div class="ac-roster"><span>${roster ? "EXPLORE THE ROSTER" : mode === "local" ? `PLAYER ${selectSeat+1} · CHOOSE A FIGHTER` : "CHOOSE YOUR FIGHTER"}</span><div>${Object.values(characters).map(c=>`<button data-action="pick" data-id="${c.id}" aria-label="Choose ${c.displayName}" aria-pressed="${active.id===c.id}" class="ac-roster-fighter ${active.id===c.id ? "is-active" : ""}"><img src="${art(c.id)}" alt=""><b>${c.displayName}</b></button>`).join("")}</div></div>
      <div class="ac-lock-panel"><span>${roster ? `${Object.keys(characters).length} FIGHTERS. FIND YOUR STYLE.` : `${active.displayName} IS YOUR PICK`}</span><button class="ac-cta" data-action="${roster ? "home" : "confirm-fighter"}"><span>${roster ? "BACK TO MENU" : mode === "local" && selectSeat === 0 ? "LOCK IN PLAYER 1" : mode === "local" ? "LOCK IN PLAYER 2" : "LOCK IN FIGHTER"}</span><b aria-hidden="true">→</b></button><small>${roster ? "" : mode === "local" && selectSeat === 0 ? "NEXT: PLAYER 2 SELECTS" : "NEXT: CHOOSE YOUR ARENA"}</small></div>
    </section>
  </main>`;
}
