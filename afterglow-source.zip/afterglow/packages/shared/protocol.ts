export type OnlineMode = "ffa" | "2v2" | "3v3";
export const PROTOCOL_VERSION = 6;
export type ClientMessage =
  | { type: "create"; character: string; capacity?: number; mode?: OnlineMode; team?: number; skin?: string }
  | { type: "join"; code: string; character: string; team?: number; skin?: string }
  | { type: "ready" }
  | { type: "input"; frame: number; mask: number }
  | { type: "hash"; frame: number; hash: string }
  | { type: "ping"; sent: number };
export type ServerMessage =
  | {
      type: "roster";
      capacity: number;
      mode: OnlineMode;
      players: { character: string; ready: boolean; team: number; skin: string }[];
    }
  | { type: "room"; code: string; seat: number }
  | {
      type: "start";
      characters: string[];
      teams: number[];
      skins: string[];
      mode: OnlineMode;
      inputDelay: number;
      maxRollbackFrames: number;
    }
  | { type: "input"; seat: number; frame: number; mask: number }
  | { type: "hash"; seat: number; frame: number; hash: string }
  | { type: "pong"; sent: number }
  | { type: "error"; message: string }
  | { type: "left"; seat: number; frame: number };
