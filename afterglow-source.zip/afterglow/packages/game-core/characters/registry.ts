import { character as tocha } from "./tocha/character.js";
import { character as a } from "./prototype-a/character.js";
import { character as b } from "./prototype-b/character.js";
import { basicAttacks } from "./common.js";
import type { CharacterDefinition } from "../types.js";
export const characters: Record<string, CharacterDefinition> = {
  [tocha.id]: tocha,
  [a.id]: a,
  [b.id]: b,
};
export function registerCharacter(character: CharacterDefinition): void {
  validateCharacter(character);
  if (Object.hasOwn(characters, character.id)) throw new Error("Duplicate character");
  characters[character.id] = character;
}

/** Fail at registration rather than midway through a fight. */
export function validateCharacter(c: CharacterDefinition): void {
  if (!/^[a-z0-9][a-z0-9-]*$/.test(c.id)) throw new Error("Invalid fighter ID");
  if (c.skins && (!c.skins.length || new Set(c.skins.map(s => s.id)).size !== c.skins.length || c.skins.some(s => !/^[a-z0-9][a-z0-9-]*$/.test(s.id) || !s.name.trim()))) throw new Error("Invalid fighter skins");
  const basic = basicAttacks(c);
  const required = [...basic.chain, basic.heavy, basic.kick, basic.crouch, basic.air, ...c.specialButtons, ...c.superButtons, ...c.specialMoves.map(m => m.move)];
  if (basic.chain.length !== 3 || new Set(basic.chain).size !== 3 || c.specialButtons.length !== 2 || new Set(c.specialButtons).size !== 2 || c.superButtons.length !== 2 || new Set(c.superButtons).size !== 2) throw new Error("Fighter needs three chain moves, two specials and two distinct supers");
  for (const id of required) if (!Object.hasOwn(c.moves, id)) throw new Error(`${c.id}: missing move ${id}`);
  for (const [id, m] of Object.entries(c.moves)) {
    if (id !== m.id) throw new Error(`${c.id}: mismatched move ID ${id}`);
    for (const n of [m.startupFrames, m.activeFrames, m.recoveryFrames, m.damage, m.hitstun, m.blockstun, m.meterCost])
      if (!Number.isInteger(n) || n < 0) throw new Error(`${c.id}: invalid timing/damage in ${id}`);
    if (m.activeFrames < 1) throw new Error(`${c.id}: move ${id} has no active frames`);
  }
  if (c.stats.maxHealth <= 0 || c.stats.gravity <= 0 || Object.values(c.stats).some(n => !Number.isFinite(n) || !Number.isInteger(n) || n < 0)) throw new Error(`${c.id}: invalid stats`);
}
Object.values(characters).forEach(validateCharacter);
