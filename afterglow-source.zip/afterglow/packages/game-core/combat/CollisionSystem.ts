import type { Box, Fighter, MoveDefinition } from "../types.js";
export function intersects(a: Box, b: Box): boolean {
  return (
    a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y
  );
}
export function worldBox(f: Fighter, b: Box): Box {
  return {
    x: f.x + (f.facing === 1 ? b.x : -b.x - b.w),
    y: f.y + b.y,
    w: b.w,
    h: b.h,
  };
}
export function hurtbox(f: Fighter): Box {
  return {
    x: f.x - 31,
    y: f.y,
    w: 62,
    h: f.state === "Crouch" || f.state.includes("Crouching") ? 84 : 154,
  };
}
export function hitboxes(f: Fighter, m: MoveDefinition | undefined): Box[] {
  return m &&
    f.moveFrame >= m.startupFrames &&
    f.moveFrame < m.startupFrames + m.activeFrames
    ? m.hitboxes.map((b) => worldBox(f, b))
    : [];
}
export function pushApart(a: Fighter, b: Fighter, width: number): void {
  if (Math.abs(a.y - b.y) > 125) return;
  const distance = Math.abs(a.x - b.x);
  if (distance >= 65) return;
  const sign = a.x <= b.x ? 1 : -1;
  const overlap = 65 - distance;
  a.x -= sign * Math.ceil(overlap / 2);
  b.x += sign * Math.floor(overlap / 2);
  if (a.x < 40) {
    b.x += 40 - a.x;
    a.x = 40;
  }
  if (b.x < 40) {
    a.x += 40 - b.x;
    b.x = 40;
  }
  if (a.x > width - 40) {
    b.x -= a.x - (width - 40);
    a.x = width - 40;
  }
  if (b.x > width - 40) {
    a.x -= b.x - (width - 40);
    b.x = width - 40;
  }
}
export function scaledDamage(
  base: number,
  combo: number,
  counter: boolean,
): number {
  return Math.max(
    1,
    Math.floor(
      (base * Math.max(30, 100 - combo * 12) * (counter ? 120 : 100)) / 10000,
    ),
  );
}
