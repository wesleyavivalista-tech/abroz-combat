import type { StageDefinition } from "../types.js";
export const trainingRoom: StageDefinition = {
  id: "the-foundry",
  name: "The Rooftop",
  width: 2400,
  floorHeight: 0,
  platforms: [
    { x: 360, y: 340, width: 480 },
    { x: 1560, y: 340, width: 480 },
  ],
  cameraBounds: [200, 2200],
  background: "#182628",
  lighting: { ambient: 1.4, key: "#dbedbb" },
  music: "foundry",
};
export const stages: Record<string, StageDefinition> = {
  [trainingRoom.id]: trainingRoom,
};
