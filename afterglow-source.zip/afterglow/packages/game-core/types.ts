export const TICK_RATE = 60;
export const enum Button {
  Left = 1,
  Right = 2,
  Up = 4,
  Down = 8,
  Light = 16,
  Medium = 32,
  Heavy = 64,
  Special = 128,
  Special2 = 256,
  Super1 = 512,
  Super2 = 1024,
}
export type InputState = number;
export type FighterState =
  | "Idle"
  | "WalkForward"
  | "WalkBackward"
  | "Crouch"
  | "JumpStartup"
  | "Jump"
  | "Fall"
  | "Land"
  | "LightAttack"
  | "MediumAttack"
  | "HeavyAttack"
  | "CrouchingAttack"
  | "AirAttack"
  | "BlockStanding"
  | "BlockCrouching"
  | "HitStunStanding"
  | "HitStunCrouching"
  | "AirHitStun"
  | "Knockdown"
  | "GetUp"
  | "DashForward"
  | "DashBackward"
  | "SpecialMove"
  | "MatchIntro"
  | "MatchWin"
  | "MatchLose"
  | "Respawning"
  | "KO"
  | (string & {});
export interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}
export interface InputSample {
  frame: number;
  mask: number;
  pressed: number;
  direction: number;
}
export interface TimelineEvent {
  frame: number;
  type: "effect" | "sound";
  id: string;
}
export interface MoveDefinition {
  displayName?: string;
  id: string;
  input: string;
  animation: string;
  state: FighterState;
  startupFrames: number;
  activeFrames: number;
  recoveryFrames: number;
  damage: number;
  hitstun: number;
  blockstun: number;
  knockback: number;
  launch: number;
  knockdown: boolean;
  meterGain: number;
  meterCost: number;
  priority: number;
  level: "high" | "mid" | "low";
  cancelRules: string[];
  cancelFrame: number;
  hitboxes: Box[];
  hurtboxes?: Box[];
  effects: string;
  events: TimelineEvent[];
  projectile?: { speed: number; lifetime: number; radius?: number; visual?: "fire" | "pentagram"; homing?: boolean };
  burn?: { duration: number; damage: number };
  hazard?: { duration: number; radius: number; damage: number; interval: number };
  auraFrames?: number;
  advance?: number;
  selfLaunch?: number;
}
export interface CharacterDefinition {
  /** Cosmetic variants; the first entry is the default. */
  skins?: { id: string; name: string }[];
  id: string;
  displayName: string;
  description: string;
  color: string;
  stats: {
    maxHealth: number;
    walkSpeed: number;
    backwardSpeed: number;
    jumpVelocity: number;
    gravity: number;
    weight: number;
  };
  animations: Record<
    string,
    { kind: "procedural" | "sprite" | "model"; duration: number }
  >;
  moves: Record<string, MoveDefinition>;
  basicAttacks?: { chain: [string, string, string]; heavy: string; kick: string; crouch: string; air: string };
  specialMoves: { motion: string; move: string }[];
  specialButtons: [string, string];
  superButtons: [string, string];
  sounds: Record<string, string>;
  effects: Record<string, string>;
  assets: Record<string, string>;
  states: Record<string, (fighter: Fighter, frame: number) => void>;
}
export interface Fighter {
  characterId: string;
  burnUntil: number;
  burnNextTick: number;
  burnDamage: number;
  burnOwner: number;
  onFireUntil: number;
  speedRemainder: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  health: number;
  lives: number;
  usedSupers: string[];
  airJumpUsed: boolean;
  respawnAt: number;
  invulnerableUntil: number;
  meter: number;
  facing: 1 | -1;
  state: FighterState;
  stateFrame: number;
  move: string | null;
  moveFrame: number;
  connected: boolean;
  stun: number;
  combo: number;
  comboDamage: number;
  lastDamage: number;
  buffer: InputSample[];
  previousInput: number;
  attackSerial: number;
  projectileSpawned: boolean;
}
export interface Projectile {
  active: boolean;
  owner: number;
  x: number;
  y: number;
  vx: number;
  life: number;
  move: string;
  serial: number;
}
export interface Hazard {
  owner: number; x: number; y: number; expiresAt: number; move: string; nextTicks: number[];
}
export interface SimulationSnapshot {
  hazards: Hazard[];
  skins: string[];
  teams: number[];
  teamMatch: boolean;
  frame: number;
  fighters: Fighter[];
  projectiles: Projectile[];
  endedAt: number;
  phase: "intro" | "fight" | "result";
  phaseFrame: number;
  hitstop: number;
  winner: number;
  training: boolean;
}
export interface CombatEvent {
  id: string;
  type: string;
  x: number;
  y: number;
  power: number;
  player: number;
}
export interface StageDefinition {
  id: string;
  name: string;
  width: number;
  floorHeight: number;
  platforms?: { x: number; y: number; width: number }[];
  cameraBounds: [number, number];
  background: string;
  lighting: { ambient: number; key: string };
  music: string;
}
export interface TrainingOptions {
  infiniteMeter: boolean;
  dummy: "stand" | "crouch" | "jump" | "block" | "afterHit";
}
