import type { Fighter } from "../types.js";
import { characters } from "../characters/registry.js";
export function createFighter(id: string, x: number, facing: 1 | -1): Fighter {
  return {
    characterId: id,
    burnUntil: 0, burnNextTick: 0, burnDamage: 0, burnOwner: -1,
    onFireUntil: 0, speedRemainder: 0,
    x,
    y: 0,
    vx: 0,
    vy: 0,
    health: characters[id].stats.maxHealth,
    lives: 3,
    usedSupers: [],
    airJumpUsed: false,
    respawnAt: 0,
    invulnerableUntil: 0,
    meter: 40,
    facing,
    state: "MatchIntro",
    stateFrame: 0,
    move: null,
    moveFrame: 0,
    connected: false,
    stun: 0,
    combo: 0,
    comboDamage: 0,
    lastDamage: 0,
    buffer: [],
    previousInput: 0,
    attackSerial: 0,
    projectileSpawned: false,
  };
}
