import { advanceStatuses, igniteTarget } from "./StatusSystem.js";
import { resolveSkin } from "../characters/skins.js";
import {
  Button,
  type Fighter,
  type SimulationSnapshot,
  type TrainingOptions,
  type CombatEvent,
  type MoveDefinition,
  type StageDefinition,
} from "../types.js";
import { basicAttacks } from "../characters/common.js";
import { characters } from "../characters/registry.js";
import { trainingRoom } from "../stages/registry.js";
import {
  record,
  motion,
  doubleTap,
  bufferedButton,
  consumeButtons,
  direction,
} from "../input/InputBuffer.js";
import {
  intersects,
  hurtbox,
  hitboxes,
  pushApart,
  scaledDamage,
} from "../combat/CollisionSystem.js";
import { enter, locked, isCounterState } from "./StateMachine.js";
import { createFighter as fighter } from "./Fighter.js";
import {
  advanceRespawns,
  resolveKnockouts,
  isActive,
  isInvulnerable,
} from "./LifeSystem.js";
import { grounded, surfaceBelow } from "./StageCollision.js";
export class GameSimulation {
  state: SimulationSnapshot;
  events: CombatEvent[] = [];
  trainingOptions: TrainingOptions = { infiniteMeter: true, dummy: "stand" };
  constructor(
    ids: string[] = ["prototype-a", "prototype-b"],
    training = false,
    public stage: StageDefinition = trainingRoom,
    teams: number[] = ids.map((_, i) => i),
    skins?: string[],
  ) {
    if (ids.length < 2 || ids.length > 6 || ids.some((id) => !characters[id]))
      throw new Error("Choose 2–6 valid fighters");
    if (skins && skins.length !== ids.length) throw new Error("One skin is required per fighter");
    const selectedSkins = ids.map((id, i) => resolveSkin(characters[id], skins?.[i]));
    const teamMatch = new Set(teams).size < ids.length;
    if (teams.length !== ids.length || teams.some(t => !Number.isInteger(t) || t < 0) ||
      (teamMatch && (![4, 6].includes(ids.length) || teams.some(t => t > 1) || teams.filter(t => t === 0).length !== ids.length / 2)))
      throw new Error("Teams must be balanced 2v2 or 3v3");
    this.state = {
      hazards: [],
      skins: selectedSkins,
      teams: [...teams],
      teamMatch,
      frame: 0,
      fighters: this.spawnFighters(ids, teams, teamMatch),
      projectiles: Array.from({ length: 48 }, () => ({
        active: false,
        owner: 0,
        x: 0,
        y: 0,
        vx: 0,
        life: 0,
        move: "",
        serial: 0,
      })),
      endedAt: 0,
      phase: training ? "fight" : "intro",
      phaseFrame: 0,
      hitstop: 0,
      winner: -1,
      training,
    };
    if (training) this.state.fighters.forEach((f) => enter(f, "Idle"));
  }
  private spawnFighters(ids: string[], teams = ids.map((_, i) => i), teamMatch = false): Fighter[] {
    return ids.map((id, i) =>
      fighter(
        id,
        teamMatch ? (teams[i] === 0 ? 300 + teams.slice(0, i).filter(t => t === 0).length * 180 : this.stage.width - 300 - teams.slice(0, i).filter(t => t === 1).length * 180) : ids.length === 2
          ? this.stage.width / 2 + (i ? 200 : -200)
          : Math.round(300 + (i * (this.stage.width - 600)) / (ids.length - 1)),
        (teamMatch ? teams[i] === 0 : i < ids.length / 2) ? 1 : -1,
      ),
    );
  }
  snapshot(): SimulationSnapshot {
    return structuredClone(this.state);
  }
  restore(s: SimulationSnapshot): void {
    this.state = structuredClone(s);
    this.events = [];
  }
  resetPositions(): void {
    const s = this.state;
    const ids = s.fighters.map((f) => f.characterId);
    s.fighters = this.spawnFighters(ids, s.teams, s.teamMatch);
    s.fighters.forEach((f) => enter(f, "Idle"));
    s.projectiles.forEach((p) => (p.active = false));
    s.hitstop = 0;
    s.hazards = [];
  }
  emit(type: string, f: Fighter, power = 1, player = 0): void {
    this.events.push({
      id: `${this.state.frame}:${this.events.length}`,
      type,
      x: f.x,
      y: f.y + 85,
      power,
      player,
    });
  }
  step(inputs: number[], forfeits: number[] = []): void {
    const s = this.state;
    this.events = [];
    s.frame++;
    s.phaseFrame++;
    if (s.phase === "result") return;
    for (const seat of forfeits) {
      const f = s.fighters[seat];
      if (!f || f.lives === 0) continue;
      f.lives = 1;
      f.health = 0;
      f.respawnAt = 0;
    }
    if (forfeits.length) {
      resolveKnockouts(s);
      if (this.state.phase === "result") return;
    }
    if (s.phase === "intro") {
      if (s.phaseFrame >= 150) {
        s.phase = "fight";
        s.phaseFrame = 0;
        s.fighters.forEach((f) => enter(f, "Idle"));
      }
      return;
    }
    const spawned = advanceRespawns(s);
    for (const player of spawned) {
      this.emit("respawn", s.fighters[player], 2, player);
    }
    if (s.training) {
      inputs = [inputs[0], this.dummyInput()];
    }
    for (let i = 0; i < s.fighters.length; i++) {
      const f = s.fighters[i];
      if (!isActive(f)) continue;
      record(f.buffer, s.frame, inputs[i], f.previousInput, f.facing);
      f.previousInput = inputs[i];
    }
    advanceStatuses(s);
    if (!s.training) {
      for (const player of resolveKnockouts(s)) this.emit("ko", s.fighters[player], 4, player);
      if (this.state.phase === "result") return;
    }
    if (s.hitstop > 0) {
      s.hitstop--;
      return;
    }
    for (let i = 0; i < s.fighters.length; i++) {
      const f = s.fighters[i];
      if (!isActive(f) || spawned.includes(i)) continue;
      const other = s.fighters
        .filter((candidate, index) => s.teams[index] !== s.teams[i] && isActive(candidate))
        .sort((a, b) => Math.abs(a.x - f.x) - Math.abs(b.x - f.x))[0];
      if (other && !f.move && !f.stun) f.facing = f.x <= other.x ? 1 : -1;
      this.updateFighter(f, inputs[i], i);
    }
    for (let i = 0; i < s.fighters.length; i++)
      for (let j = i + 1; j < s.fighters.length; j++)
        if (
          !spawned.includes(i) &&
          !spawned.includes(j) &&
          isActive(s.fighters[i]) &&
          isActive(s.fighters[j])
        )
          pushApart(s.fighters[i], s.fighters[j], this.stage.width);
    const contacts: {
      attacker: number;
      defender: number;
      move: MoveDefinition;
      projectile?: number;
    }[] = [];
    for (let i = 0; i < s.fighters.length; i++) {
      const f = s.fighters[i],
        m = f.move ? characters[f.characterId].moves[f.move] : undefined;
      if (isActive(f) && m && !f.connected)
        s.fighters.forEach((d, defender) => {
          if (s.teams[defender] !== s.teams[i] && hitboxes(f, m).some((b) => this.hurts(d, b)))
            contacts.push({ attacker: i, defender, move: m });
        });
    }
    for (let i = 0; i < s.projectiles.length; i++) {
      const p = s.projectiles[i];
      if (!p.active) continue;
      const projectileSpec = characters[s.fighters[p.owner].characterId].moves[p.move].projectile;
      if (projectileSpec?.homing) {
        const target = s.fighters.filter((f, seat) => s.teams[seat] !== s.teams[p.owner] && isActive(f)).sort((a, b) => Math.abs(a.x - p.x) + Math.abs(a.y + 85 - p.y) - Math.abs(b.x - p.x) - Math.abs(b.y + 85 - p.y))[0];
        if (target) {
          p.vx = Math.sign(target.x - p.x) * projectileSpec.speed;
          p.y += Math.max(-8, Math.min(8, target.y + 85 - p.y));
        }
      }
      const radius = projectileSpec?.radius ?? 22;
      p.x += p.vx;
      p.life--;
      if (p.life <= 0 || p.x < 0 || p.x > this.stage.width) {
        p.active = false;
        continue;
      }
      const defender = s.fighters.findIndex(
        (d, index) =>
          s.teams[index] !== s.teams[p.owner] &&
          this.hurts(d, { x: p.x - radius, y: p.y - radius, w: radius * 2, h: radius * 2 }),
      );
      if (defender >= 0)
        contacts.push({
          attacker: p.owner,
          defender,
          move: characters[s.fighters[p.owner].characterId].moves[p.move],
          projectile: i,
        });
    }
    // Collect first: equal-priority simultaneous strikes trade, higher priority wins.
    const melee = contacts.filter((c) => c.projectile === undefined);
    const counters = s.fighters.map(isCounterState);
    for (const c of contacts) {
      if (
        c.projectile === undefined &&
        melee.some(
          (o) =>
            o.attacker === c.defender &&
            o.defender === c.attacker &&
            o.move.priority > c.move.priority,
        )
      )
        continue;
      this.hit(
        c.attacker,
        c.move,
        inputs[c.defender],
        counters[c.defender],
        c.defender,
        c.projectile === undefined ? undefined : Math.sign(s.projectiles[c.projectile].vx),
      );
      if (c.projectile !== undefined)
        s.projectiles[c.projectile].active = false;
      else s.fighters[c.attacker].connected = true;
    }
    for (const f of s.fighters) {
      if (s.training) {
        if (
          !f.stun &&
          !f.burnUntil &&
          grounded(f, this.stage) &&
          !["Knockdown", "GetUp"].includes(f.state)
        )
          f.health = characters[f.characterId].stats.maxHealth;
        if (this.trainingOptions.infiniteMeter) f.meter = 100;
      }
    }
    if (!s.training) {
      for (const player of resolveKnockouts(s))
        this.emit("ko", s.fighters[player], 4, player);
    }
  }

  hurts(
    d: Fighter,
    b: { x: number; y: number; w: number; h: number },
  ): boolean {
    if (
      !isActive(d) ||
      isInvulnerable(d, this.state.frame) ||
      ["Knockdown", "GetUp", "KO"].includes(d.state)
    )
      return false;
    const move = d.move ? characters[d.characterId].moves[d.move] : undefined;
    const boxes = move?.hurtboxes?.map((h) => ({
      x: d.x + (d.facing === 1 ? h.x : -h.x - h.w),
      y: d.y + h.y,
      w: h.w,
      h: h.h,
    })) ?? [hurtbox(d)];
    return boxes.some((h) => intersects(b, h));
  }
  dummyInput(): number {
    const f = this.state.fighters[1];
    const back = f.facing === 1 ? Button.Left : Button.Right;
    switch (this.trainingOptions.dummy) {
      case "crouch":
        return Button.Down;
      case "jump":
        return Button.Up;
      case "block":
        return back | Button.Down;
      case "afterHit":
        return f.combo > 0 ? back : 0;
      default:
        return 0;
    }
  }
  updateFighter(f: Fighter, input: number, player: number): void {
    const def = characters[f.characterId];
    const basics = basicAttacks(def);
    const boosted = f.onFireUntil > this.state.frame;
    const speed = boosted ? 1.5 : 1;
    f.stateFrame++;
    if (grounded(f, this.stage)) f.airJumpUsed = false;
    const jumpPressed = !!((f.buffer.at(-1)?.pressed ?? 0) & Button.Up);
    if (
      jumpPressed &&
      !grounded(f, this.stage) &&
      !f.airJumpUsed &&
      !f.move &&
      !locked(f) &&
      ["Jump", "Fall"].includes(f.state)
    ) {
      f.airJumpUsed = true;
      f.vy = def.stats.jumpVelocity;
      const horizontal =
        (input & Button.Right ? 1 : 0) - (input & Button.Left ? 1 : 0);
      if (horizontal) f.vx = horizontal * 4;
      enter(f, "Jump");
      this.emit("dust", f, 2, player);
    }
    if (f.stun > 0) {
      f.stun--;
      // Airborne movement is integrated once below, alongside gravity.
      if (grounded(f, this.stage)) f.x += f.vx;
      f.vx = Math.trunc((f.vx * 8) / 10);
      if (!f.stun) {
        if (!grounded(f, this.stage)) {
          if (f.state !== "AirHitStun") enter(f, "Fall");
        } else if (f.state === "AirHitStun") enter(f, "Knockdown");
        else enter(f, "Idle");
      }
    } else if (f.state === "AirHitStun") {
      /* Remain vulnerable in the air until landing. */
    } else if (f.state === "Knockdown") {
      if (f.stateFrame >= 32) enter(f, "GetUp");
    } else if (f.state === "GetUp") {
      if (f.stateFrame >= 18) enter(f, "Idle");
    } else if (f.state === "JumpStartup") {
      if (f.stateFrame >= 3) {
        f.vy = def.stats.jumpVelocity;
        f.y += 1;
        enter(f, "Jump");
        this.emit("dust", f, 1, player);
      }
    } else if (f.state === "Land") {
      if (f.stateFrame >= 3) enter(f, "Idle");
    } else {
      const request = this.requestMove(f, input);
      const current = f.move ? def.moves[f.move] : undefined;
      if (
        request &&
        (!current ||
          (((f.move === basics.chain[0] && request === basics.chain[1]) ||
            (f.move === basics.chain[1] && request === basics.chain[2])) &&
            f.moveFrame >= current.startupFrames + current.activeFrames + 3) ||
          (f.connected &&
            f.moveFrame >= current.cancelFrame &&
            current.cancelRules.includes(request)))
      ) {
        const m = def.moves[request];
        const superMove = def.superButtons.includes(request);
        const cost = superMove ? 100 : m?.meterCost;
        if (
          m &&
          cost !== undefined &&
          f.meter >= cost &&
          (!superMove || !f.usedSupers.includes(request))
        ) {
          f.move = request;
          f.moveFrame = -1;
          f.speedRemainder = 0;
          f.connected = false;
          f.projectileSpawned = false;
          f.attackSerial++;
          f.meter -= cost;
          if (superMove) f.usedSupers.push(request);
          enter(f, m.state);
          consumeButtons(f.buffer);
          this.emit(
            superMove ? "super" : "attack",
            f,
            superMove ? 5 : 1,
            player,
          );
        }
      }
      if (f.move) {
        const m = def.moves[f.move];
        const previousFrame = f.moveFrame;
        f.speedRemainder += boosted ? 3 : 2;
        const advance = Math.floor(f.speedRemainder / 2);
        f.speedRemainder %= 2;
        f.moveFrame += advance;
        const activates = previousFrame < m.startupFrames && f.moveFrame >= m.startupFrames;
        if (activates && m.auraFrames) f.onFireUntil = this.state.frame + m.auraFrames;
        if (activates && m.hazard && this.state.hazards.length < 48) {
          // Fixed cap covers six boosted casters while every sigil keeps its full lifetime.
          this.state.hazards.push({owner: player, x: f.x, y: surfaceBelow(this.stage, f.x, f.y), expiresAt: this.state.frame + m.hazard.duration, move: m.id, nextTicks: this.state.fighters.map(() => this.state.frame + 1)});
        }
        for (const event of m.events)
          if (event.frame > previousFrame && event.frame <= f.moveFrame) this.emit(event.id, f, 1, player);
        if (
          m.advance &&
          f.moveFrame >= m.startupFrames &&
          f.moveFrame < m.startupFrames + m.activeFrames
        )
          f.x += m.advance * f.facing * speed;
        if (m.selfLaunch && activates) {
          f.vy = m.selfLaunch;
          f.y += 1;
        }
        if (
          m.projectile &&
          activates &&
          !f.projectileSpawned
        ) {
          const slot = this.state.projectiles.find((p) => !p.active);
          if (slot) {
            Object.assign(slot, {
              active: true,
              owner: player,
              x: f.x + f.facing * 70,
              y: f.y + (m.projectile.visual === "pentagram" ? 165 : 100),
              vx: m.projectile.speed * f.facing,
              life: m.projectile.lifetime,
              move: m.id,
              serial: f.attackSerial,
            });
          }
          f.projectileSpawned = true;
          this.emit("projectile", f, 2, player);
        }
        if (
          f.moveFrame >=
          m.startupFrames + m.activeFrames + m.recoveryFrames
        ) {
          f.move = null;
          enter(f, grounded(f, this.stage) ? "Idle" : "Fall");
        }
      } else if (grounded(f, this.stage) && !locked(f)) {
        f.combo = 0;
        f.comboDamage = 0;
        const dir = direction(input, f.facing);
        if (input & Button.Up) {
          f.vx = (input & Button.Right ? 4 : 0) - (input & Button.Left ? 4 : 0);
          enter(f, "JumpStartup");
        } else if (
          ["DashForward", "DashBackward"].includes(f.state) &&
          f.stateFrame < 12
        ) {
          f.x += f.facing * (f.state === "DashForward" ? 11 : -9) * speed;
        } else if (doubleTap(f.buffer, 6) || doubleTap(f.buffer, 4)) {
          enter(f, doubleTap(f.buffer, 6) ? "DashForward" : "DashBackward");
          this.emit("dash-dust", f, 1, player);
        } else if (input & Button.Down) {
          enter(f, "Crouch");
        } else if (dir === 6 || dir === 4) {
          const forward = dir === 6;
          enter(f, forward ? "WalkForward" : "WalkBackward");
          f.x +=
            f.facing *
            (forward ? def.stats.walkSpeed : -def.stats.backwardSpeed) * speed;
        } else enter(f, "Idle");
      }
    }
    if (!grounded(f, this.stage)) {
      const previousY = f.y;
      f.x += f.vx * (f.stun || f.state === "AirHitStun" ? 1 : speed);
      f.y += f.vy;
      f.vy -= def.stats.gravity;
      const surface = surfaceBelow(this.stage, f.x, previousY);
      if (f.vy <= 0 && f.y <= surface) {
        f.y = surface;
        f.airJumpUsed = false;
        f.vy = 0;
        f.vx = 0;
        if (
          f.state === "AirHitStun" ||
          (f.stun > 0 && f.state.includes("HitStun"))
        ) {
          f.stun = 0;
          f.move = null;
          enter(f, "Knockdown");
        } else if (!f.move) enter(f, "Land");
        this.emit("landing-dust", f, 1, player);
      } else if (
        f.vy <= 0 &&
        !f.move &&
        !f.stun &&
        !["AirHitStun", "Knockdown", "GetUp"].includes(f.state)
      )
        enter(f, "Fall");
    }
    f.x = Math.max(40, Math.min(this.stage.width - 40, Math.round(f.x * 2) / 2));
    def.states[f.state]?.(f, this.state.frame);
  }
  requestMove(f: Fighter, input: number): string | null {
    const frame = this.state.frame,
      def = characters[f.characterId];
    const basics = basicAttacks(def);
    if (bufferedButton(f.buffer, frame, Button.Super2))
      return def.superButtons[1];
    if (bufferedButton(f.buffer, frame, Button.Super1))
      return def.superButtons[0];
    // A fresh repeat press can queue one follow-up during the current chain move.
    // Consuming presses at move start prevents holding a button from auto-chaining.
    const chainPress = (f.move === basics.chain[0] || f.move === basics.chain[1]) &&
      f.buffer.some(sample => frame - sample.frame <= 32 && !!(sample.pressed & Button.Light));
    const attack = chainPress || [Button.Light, Button.Medium, Button.Heavy].some((b) =>
      bufferedButton(f.buffer, frame, b),
    );
    if (attack) {
      for (const special of def.specialMoves)
        if (motion(f.buffer, special.motion)) return special.move;
    }
    if (bufferedButton(f.buffer, frame, Button.Special2))
      return def.specialButtons[1];
    if (bufferedButton(f.buffer, frame, Button.Special))
      return def.specialButtons[0];
    if (!attack) return null;
    if (!grounded(f, this.stage)) return basics.air;
    if (input & Button.Down) return basics.crouch;
    if (bufferedButton(f.buffer, frame, Button.Medium)) return basics.heavy;
    if (bufferedButton(f.buffer, frame, Button.Heavy)) return basics.kick;
    if (f.move === basics.chain[0]) return basics.chain[1];
    if (f.move === basics.chain[1]) return basics.chain[2];
    return basics.chain[0];
  }
  hit(
    attacker: number,
    m: MoveDefinition,
    input: number,
    counter: boolean,
    defender = 1 - attacker,
    impactDirection: number = this.state.fighters[attacker].facing,
  ): void {
    const s = this.state,
      a = s.fighters[attacker],
      d = s.fighters[defender];
    if (s.teams[attacker] === s.teams[defender] || !isActive(d) || isInvulnerable(d, s.frame)) return;
    const back = d.facing === 1 ? Button.Left : Button.Right;
    const crouch = !!(input & Button.Down);
    const canBlock =
      grounded(d, this.stage) &&
      !d.move &&
      (!d.stun || d.state.startsWith("Block"));
    const blocked =
      canBlock &&
      !!(input & back) &&
      (m.level === "mid" || (m.level === "low" ? crouch : !crouch));
    d.move = null;
    d.vx = impactDirection * (blocked ? Math.ceil(m.knockback / 2) : m.knockback);
    d.stun = blocked ? m.blockstun : m.hitstun + (counter ? 4 : 0);
    if (blocked) {
      enter(d, crouch ? "BlockCrouching" : "BlockStanding");
      d.meter = Math.min(100, d.meter + 3);
      this.emit("block", d, 1, defender);
    } else {
      const damage = scaledDamage(m.damage, d.combo, counter);
      d.health = Math.max(s.training ? 1 : 0, d.health - damage);
      d.combo++;
      d.comboDamage += damage;
      d.lastDamage = damage;
      if (m.burn) igniteTarget(s, d, attacker, m.burn.duration, m.burn.damage);
      if (m.launch || !grounded(d, this.stage) || m.knockdown) {
        d.vy = m.launch || 9;
        d.y += 1;
        enter(d, "AirHitStun");
      } else enter(d, crouch ? "HitStunCrouching" : "HitStunStanding");
      a.meter = Math.min(100, a.meter + m.meterGain);
      d.meter = Math.min(100, d.meter + 4);
      this.emit(counter ? "counter" : m.effects, d, m.priority, defender);
    }
    s.hitstop = Math.max(s.hitstop, blocked ? 4 : m.priority + 5);
  }
}
export function hashState(s: SimulationSnapshot): string {
  const text = JSON.stringify(s);
  let hash = 2166136261;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16);
}
