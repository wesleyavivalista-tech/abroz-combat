import type { Fighter, SimulationSnapshot } from "../types.js";
import { TICK_RATE } from "../types.js";
import { createFighter } from "./Fighter.js";
import { enter } from "./StateMachine.js";
export const RESPAWN_FRAMES = 2 * TICK_RATE;
export const INVULNERABLE_FRAMES = 2 * TICK_RATE;
export function isActive(f: Fighter): boolean {
  return f.lives > 0 && f.health > 0 && f.respawnAt === 0;
}
export function isInvulnerable(f: Fighter, frame: number): boolean {
  return frame < f.invulnerableUntil;
}

/** Absolute simulation-frame deadlines keep both timers independent of hit stop. */
export function advanceRespawns(s: SimulationSnapshot): number[] {
  const spawned: number[] = [];
  for (let i = 0; i < s.fighters.length; i++) {
    const f = s.fighters[i];
    if (f.respawnAt === 0 || s.frame < f.respawnAt || f.lives === 0) continue;
    const other = s.fighters.find(
      (candidate, index) => s.teams[index] !== s.teams[i] && candidate.lives > 0,
    );
    // Position remains frozen while waiting, including airborne defeat locations.
    const fresh = createFighter(
      f.characterId,
      f.x,
      other ? (f.x <= other.x ? 1 : -1) : f.facing,
    );
    fresh.y = f.y;
    fresh.lives = f.lives;
    fresh.usedSupers = [...f.usedSupers];
    fresh.meter = f.meter;
    fresh.attackSerial = f.attackSerial + 1;
    fresh.invulnerableUntil = s.frame + INVULNERABLE_FRAMES;
    fresh.state = fresh.y > 0 ? "Fall" : "Idle";
    Object.assign(f, fresh);
    spawned.push(i);
  }
  return spawned;
}
/** Resolve both deaths together so equal-priority lethal trades remain symmetric. */
export function resolveKnockouts(s: SimulationSnapshot): number[] {
  const lost: number[] = [];
  for (let i = 0; i < s.fighters.length; i++) {
    const f = s.fighters[i];
    if (f.health > 0 || f.respawnAt !== 0 || f.lives === 0) continue;
    f.lives--;
    f.burnUntil = f.burnNextTick = f.burnDamage = f.onFireUntil = 0;
    f.burnOwner = -1;
    s.hazards = s.hazards.filter(h => h.owner !== i);
    f.health = 0;
    f.move = null;
    f.stun = 0;
    f.vx = 0;
    f.vy = 0;
    f.combo = 0;
    f.comboDamage = 0;
    f.buffer = [];
    f.previousInput = 0;
    f.invulnerableUntil = 0;
    f.respawnAt = f.lives > 0 ? s.frame + RESPAWN_FRAMES : 0;
    enter(f, f.lives > 0 ? "Respawning" : "KO");
    for (const p of s.projectiles) if (p.owner === i) p.active = false;
    lost.push(i);
  }
  if (lost.length && new Set(s.fighters.flatMap((f, i) => f.lives > 0 ? [s.teams[i]] : [])).size <= 1) {
    s.phase = "result";
    s.phaseFrame = 0;
    s.endedAt = s.frame;
    s.winner = s.fighters.findIndex((f) => f.lives > 0);
    s.fighters.forEach((f, i) => {
      f.move = null;
      f.respawnAt = 0;
      enter(f, s.winner >= 0 && s.teams[i] === s.teams[s.winner] && f.lives > 0 ? "MatchWin" : "KO");
    });
    s.projectiles.forEach((p) => (p.active = false));
    s.hazards = [];
  }
  return lost;
}
