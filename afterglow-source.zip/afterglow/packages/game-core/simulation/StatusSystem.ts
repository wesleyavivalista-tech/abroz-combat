import type { Fighter, SimulationSnapshot } from "../types.js";
import { characters } from "../characters/registry.js";
import { isActive, isInvulnerable } from "./LifeSystem.js";
export const BURN_INTERVAL = 30;
export function igniteTarget(s: SimulationSnapshot, target: Fighter, owner: number, duration: number, damage: number): void {
  const seat = s.fighters.indexOf(target);
  if (!isActive(target) || isInvulnerable(target, s.frame) || s.teams[seat] === s.teams[owner]) return;
  // Refresh, never stack. Repeated aura contacts must not postpone the next tick.
  if (!target.burnUntil || target.burnUntil < s.frame) target.burnNextTick = s.frame + BURN_INTERVAL;
  target.burnUntil = Math.max(target.burnUntil, s.frame + duration);
  target.burnDamage = Math.max(target.burnDamage, damage);
  target.burnOwner = owner;
}
function damage(s: SimulationSnapshot, f: Fighter, amount: number): void {
  if (!isActive(f) || isInvulnerable(f, s.frame)) return;
  f.health = Math.max(s.training ? 1 : 0, f.health - amount);
  f.lastDamage = amount;
}
/** Absolute ticks keep effects deterministic during hitstop and rollback. No hitstun. */
export function advanceStatuses(s: SimulationSnapshot): void {
  for (const f of s.fighters) {
    if (f.burnUntil && s.frame <= f.burnUntil && s.frame >= f.burnNextTick) {
      damage(s, f, f.burnDamage);
      f.burnNextTick += BURN_INTERVAL;
    }
    if (s.frame > f.burnUntil) {
      f.burnUntil = f.burnNextTick = f.burnDamage = 0;
      f.burnOwner = -1;
    }
    if (s.frame >= f.onFireUntil) f.onFireUntil = 0;
  }
  s.fighters.forEach((f, owner) => {
    if (!isActive(f) || !f.onFireUntil) return;
    s.fighters.forEach(d => {
      if (Math.abs(d.x - f.x) <= 72 && Math.abs(d.y - f.y) < 130)
        igniteTarget(s, d, owner, 180, 10);
    });
  });
  s.hazards = s.hazards.filter(h => s.frame < h.expiresAt);
  for (const h of s.hazards) {
    const spec = characters[s.fighters[h.owner].characterId].moves[h.move].hazard!;
    s.fighters.forEach((f, i) => {
      if (s.teams[i] === s.teams[h.owner] || !isActive(f) || isInvulnerable(f, s.frame)) return;
      if (Math.abs(f.x - h.x) <= spec.radius + 25 && Math.abs(f.y - h.y) <= 55 && s.frame >= h.nextTicks[i]) {
        damage(s, f, spec.damage);
        h.nextTicks[i] = s.frame + spec.interval;
      }
    });
  }
}
