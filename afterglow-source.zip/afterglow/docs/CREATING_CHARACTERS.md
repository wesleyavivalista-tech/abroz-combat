# Creating a fighter

A fighter is a data package, with an optional rendering adapter. Core simulation never imports Three.js. Vector and Brut currently use pixel sprite atlases, with separate detailed menu portraits. Each new fighter can have independent move IDs, animations and artwork.

## What to send for a new fighter

- Name, appearance references, clothing, proportions and personality.
- Three moves in the first-button sequence; one slower, stronger second-button attack; one third-button attack.
- Crouching and airborne attacks (or tell us which existing attacks to adapt).
- Two repeatable specials and two supers, with names and descriptions of movement, range and effects.
- Unique mechanics, desired strengths and weaknesses, and any signature poses.

Exact frame counts are optional at intake. We can propose timing and balance after implementing the intended behavior. Each super requires full energy, consumes the bar and is usable once per fight. Three lives, a two-second respawn at the death position and two-second protection remain shared rules.

## 1. Create a package

Copy `packages/game-core/characters/prototype-a` to a new directory. Split the definition into `character.ts`, `moves.ts`, `animations.ts`, `states.ts`, `hitboxes.ts`, `sounds.ts` and `effects.ts` as the fighter grows. Keep binary assets in the client public directory (or an asset CDN) and reference URLs from `assets`.

## 2. Define the character

```ts
import type { CharacterDefinition } from "../../types.js";
import { moves } from "./moves.js";

export const character: CharacterDefinition = {
  id: "fighter-01",
  displayName: "YOUR FIGHTER",
  description: "An original combat style",
  color: "#a9d9ea",
  stats: {
    maxHealth: 1000,
    walkSpeed: 5,
    backwardSpeed: 4,
    jumpVelocity: 22,
    gravity: 1,
    weight: 100,
  },
  moves,
  specialMoves: [{ motion: "236", move: "special" }],
  specialButtons: ["special", "second-special"],
  superButtons: ["super-one", "super-two"],
  animations: { light: { kind: "procedural", duration: 18 } },
  sounds: {},
  effects: {},
  assets: {},
  states: {},
};
```

Simulation positions are integers: **100 units = 1 metre**. Speeds are units per tick. Positive Y is up. One tick = 1/60 second. `weight` is reserved metadata in this version; knockback is specified by the attacking move.

## 3. Register it

Import the definition in `characters/registry.ts`, or call `registerCharacter(character)` from a content bootstrap module before starting matches. Do not change `GameSimulation`. The room server reads the shared character registry; no separate fighter allowlist is needed. Import the content bootstrap in both client and server before accepting matches. All clients and the server must ship identical content.

## 4. Import assets

`assets` maps names to URLs. `AssetManager.load()` fetches and caches all declared bytes before the match. The current pixel fighters use texture atlases loaded by `rendering/VisualRegistry.ts`. Production model/sprite adapters should decode their cached resources before sending online ready. Character artwork, sounds and VFX must be original or properly licensed.

## 5. Define states

The built-in state machine covers movement, normal attacks, special attacks, standing/crouching guards, air hit stun, knockdown, recovery, respawning and match outcomes. Additional string state IDs are supported. `states[stateId]` is an optional deterministic hook called every simulation update for that state.

Hooks may mutate gameplay fields on the fighter. They must never read time, DOM, network, random numbers or renderer data. New persistent mechanic fields require extending the typed snapshot and replay tests; don't store hidden mutable state in a closure.

## 6. Define animations

Animation identifiers are independent of combat timing. Rendering receives the authoritative fighter state, state frame, move ID and move frame. Use `FighterVisual` and `registerFighterVisual()` for a character-specific 3D rig or sprite implementation. A sprite adapter is provided. Do not activate damage based on a visible animation frame or a GPU callback.

## 7. Define normals

```ts
import { move } from "../common.js";
export const moves = {
  light: move("light", {
    startupFrames: 5,
    activeFrames: 3,
    recoveryFrames: 10,
    damage: 48,
    hitstun: 19,
    blockstun: 11,
    cancelFrame: 6,
    cancelRules: ["special"],
    hitboxes: [{ x: 20, y: 70, w: 83, h: 38 }],
  }),
  // Also define chain2, chain3, heavy, kick, crouch, air, two specials and two supers.
};
```

Frame 0 begins the move. A 5/3/10 move is active on frames **5, 6, 7**, and recovers when its move frame reaches 18. Cancels require connection (hit or block), the configured frame and an allowed target. Equal priority simultaneous melee hits trade; higher priority wins. Each move activation can hit once.

The first input selects `light`, then fresh repeat presses queue `chain2` and `chain3`. The second input selects `heavy`; `kick` is selected with the third input, `crouch` with down + attack, `air` with attack while airborne. Bindings belong to InputManager, not the character.

### Independent basic attack names

Set optional `basicAttacks` on the character definition to use unique IDs:

```ts
basicAttacks: {
  chain: ["jab", "cross", "roundhouse"],
  heavy: "hammer-blow",
  kick: "front-kick",
  crouch: "sweep",
  air: "flying-kick",
},
```

Every referenced move must exist in `moves`. Omitting this mapping uses the current default IDs. Registration validates required moves, distinct chain/special/super slots, move IDs, basic timing and stats. This is an early error check, not a substitute for gameplay tests. Set each move's `displayName` for readable menus.

### Portrait and playable art registration

Call `registerFighterPresentation(id, { portrait, style, facing })` from `apps/client/src/ui/FighterPresentation.ts` before opening menus. `facing` describes the source portrait direction (`left` or `right`); the selector mirrors it for a face-off. Unconfigured fighters use a neutral placeholder. The roster and server accept registered fighters without editing an ID switch. The home banner intentionally features Vector and Brut.

Register the playable artwork with `registerFighterVisual(id, factory)` in `rendering/VisualRegistry.ts`. The factory returns a `FighterVisual` with update/dispose methods. A generic `SpriteFighterRenderer` is available, or provide a custom adapter. The existing `PixelFighterRenderer` uses atlas coordinates specific to Vector and Brut: new artwork requires its own atlas mapping and animation poses. Merely changing a texture URL will not produce a correctly animated new fighter.

Decode textures before match entry and register the factory before visuals are created. Extend `loadFighterSprites()` (awaited by `SceneRenderer.prepareFighters()`) for new sprite resources; declaring asset bytes alone does not decode them. Include distinct walk/dash, crouch attacks, jump, guard, damage and victory poses. Check grounded foot alignment, both facing directions and silhouette continuity across frames.

## 8. Define specials

`specialMoves` is checked in array order, so put overlapping complex motions before simpler motions. A three-direction motion such as `623` must complete inside 22 frames. Motions are relative to the fighter's facing **when each input is recorded**. `236`, `214`, `623`, `22`, `41236` and `63214` are representable. Charge durations and arbitrary button chords are future input-recognizer extensions, not implemented mechanics.

The I/U buttons select the two IDs in `specialButtons` for prototype accessibility. Both specials must be defined in `moves`. Motion + any normal selects the matching special. `meterCost` gates activation. `projectile` defines speed/lifetime; `advance` moves forward during active frames; `selfLaunch` launches the attacker on its first active frame.

## 9. Define hitboxes and hurtboxes

Boxes use fighter-local integer coordinates. Local positive X faces the opponent. Core mirrors them for negative facing. `hitboxes` are active only during the move's active window. Optional move `hurtboxes` override the default standing/crouching hurtbox for that move. Pushboxes are separate, core-managed 64-unit bodies. F1 shows hitboxes in pink, hurtboxes in blue and pushboxes in lime.

`level`: mid is blocked standing or crouching; low requires crouching; high requires standing. Hold away from the opponent to guard. A stunned or attacking fighter cannot newly guard; an existing guard can continue through block stun.

## 10. Define sounds and effects

Moves emit their `effects` ID on a hit and may emit named timeline events through `events`. Character `sounds`/`effects` dictionaries remap IDs before presentation. Extend the client managers with your new effect or audio assets. Rollback replays suppress presentation events, preventing duplicate sound spam. The default AudioManager synthesizes placeholders; it does not ship voice recordings.

## 11. Test in training

Select the fighter, enter The Rooftop, enable F1 and test:

- Ground/air movement, opposite facing, crossovers and both corners.
- All frame windows, hurtboxes, priority, counter hits and cancels.
- Stand/crouch/jump/block/block-after-hit dummy modes.
- Damage scaling, meter cost and projectile pool limits.
- Snapshot/replay equality with seeded input sequences.
- Online under each latency preset with desync diagnostics enabled.

## 12. Balance

Change frame data in the character package, not engine branches. Add regression tests for intended combo routes and boundary cases. Do not tune rendering to compensate for combat timing. Document move range, startup, active, recovery, damage and block behavior together.

## Boundaries of this foundation

Throws, armor, parries, wall bounces, cinematic supers, AI and charge motions are future mechanics. The snapshot/input/visual separation supports adding them, but they are not claimed as implemented.

Lives and respawn protection belong to the engine. Character attacks must use core collision/damage APIs, which reject protected targets. Custom state hooks should not change `lives`, `respawnAt` or `invulnerableUntil` unless implementing a deliberately tested mechanic.

## Super move definitions

Provide two move IDs in `superButtons` and define both in `moves`, with display names and 100 meter cost. The engine independently enforces full meter, consumes 100 energy and records the activated ID in `Fighter.usedSupers`. This usage array is snapshotted, restored during rollback and carried across respawns; new matches reset it. Failed activation does not spend a use. A successfully started Super spends the use even if it misses or is interrupted. Character animations can reuse another animation ID while retaining distinct move and damage definitions.

## Multiple skins per fighter

Plan at least two looks for each new fighter, with no fixed maximum. Send a skin name and appearance reference for each. Skins share the fighter's combat definition: moves, timing, damage, hitboxes, stats and super allowances do not vary by outfit.

Declare the catalogue on `CharacterDefinition`:

```ts
skins: [
  { id: "original", name: "Original" },
  { id: "street", name: "Street Wear" },
  { id: "night", name: "Night Run" },
],
```

The first entry is the default. IDs must be unique lowercase slugs; names must not be empty. Older fighters without a catalogue receive one `original` entry. Vector and Brut currently retain only their existing Original artwork; no additional outfits have been invented for this infrastructure change.

Add skin-specific portrait URLs (and optional facing) to the existing presentation registration:

```ts
registerFighterPresentation("your-fighter", {
  portrait: "/art/your-fighter-original.png",
  style: "YOUR FIGHTING STYLE",
  facing: "right",
  skins: {
    street: { portrait: "/art/your-fighter-street.png" },
    night: { portrait: "/art/your-fighter-night.png" },
  },
});
```

Use `registerFighterVisual(characterId, factory, skinId)` for each playable look. Use `registerSkinLoader(characterId, skinId, asyncLoader)` before match loading to await texture decoding and register its factory. Include all animation resources required by the outfit (combat, movement, crouching). Factories must create independent per-fighter materials/state when two players use the same look. Assets may share immutable textures. Missing portrait/visual variants fall back to the base look during development; do not ship a named outfit until its actual artwork is registered.

The selector lists all declared skins; each local player has an independent selection. Switching fighters resets that seat to the new fighter's default; editing the same fighter retains its selection. Archive previews are separate. Online create/join messages include the chosen skin, the server validates it against the fighter catalogue, and roster/start messages distribute it. Skin IDs are included in snapshots so rollback, life loss, respawns and match results retain the look. The renderer recreates visuals when the fighter/skin pair changes.

When adding another skin, extend the catalogue and artwork registration. Do not copy the fighter or its moves into another character ID. Validate selector previews, duplicate picks, mirrored poses, respawns and online agreement. `tests/skins.test.ts` exercises three skins, unchanged combat, server validation/assignment, snapshots and independent rendering factories.
