# AFTERGLOW — engine architecture

## Boundaries

- `packages/game-core`: pure TypeScript, no DOM, clock, renderer, audio, or network. One authoritative step consumes one input bitmask per fighter (2–6). Integer coordinates (100 units per metre), velocities, timers and frame data at 60 Hz.
- `characters`: registered data packages own statistics, moves, hitboxes, animation identifiers, sound/effect mappings and optional deterministic state hooks.
- `stages`: gameplay bounds and presentation metadata.
- `packages/networking`: input history, bounded snapshots, prediction and rollback. Never transmits fighter positions.
- `apps/server`: WebSocket rooms and validated input relay; assigns seats and a shared match configuration. No simulation authority or anti-cheat guarantee in this prototype.
- `apps/client`: fixed tick driver, keyboard/gamepad adapters, Three.js presentation, DOM UI, synthesized audio and asset loading. Renderer reads snapshots; it never drives combat.

## Tick pipeline

Buffer relative inputs → state transitions → movement/gravity → pushboxes → collect simultaneous hit candidates → priority/trades → damage/block/stun/meter → life loss / match result. Snapshots include input buffers, projectiles, attack identifiers and all other future-affecting state. Presentation events are emitted separately and suppressed during rollback replays.

## Rollback

Store the state BEFORE each frame. Schedule local input at current frame + delay. Predict missing remote input from the latest confirmed preceding input. Late corrections restore the earliest affected snapshot and replay to the present. At the prediction limit, stall rather than silently discard input. Confirmed-state hashes detect divergence. Histories are bounded. Ordered WebSocket transport avoids lost inputs but suffers head-of-line blocking; WebRTC/UDP transport can be added behind the same protocol later.

## Primary risks and decisions

1. Determinism: integer simulation, stable iteration and no random/real-time calls. Hash and replay tests protect this boundary.
2. Latency: default 2-frame input delay / 8-frame prediction; higher latency causes visible stalls. Debug latency is configurable.
3. Side effects: render VFX only for new forward ticks; rollback may remove a predicted visual hit. Audio is deliberately not replayed.
4. Background tabs: cap catch-up work and pause prediction at the remote horizon. Online matches do not locally pause.
5. Extension: moves and state hooks are data driven; model/sprite rendering uses an adapter boundary. Advanced mechanics may extend the engine, but ordinary roster additions do not.
6. Deployment: HTTPS requires WSS; configure VITE_WS_URL and server ALLOWED_ORIGINS. Rooms are in memory and single-instance. Scaling requires room routing/persistence.

## Implementation order

Core and tests → character packages → client/rendering → match menus/training → relay/rollback → integration tests and production build.

## Three-life survival matches

`LifeSystem` owns three starting lives, respawning and protection. Respawn/protection deadlines are absolute simulation frames stored on each fighter: death +120 ticks respawns; spawn +120 ticks ends invulnerability. These timers continue through hit stop and roll back with snapshots. Waiting fighters cannot act, be hit or participate in pushbox resolution. Remaining fighters keep health and meter. The match has no timeout or repeated rounds. Simultaneous final eliminations draw. Online results are shown only after the lethal frame is confirmed.

Respawn position is the fighter’s frozen defeat X/Y. The respawn tick skips movement/gravity and pushbox separation so neither held input nor an overlapping opponent relocates the spawn. Normal movement, gravity and pushboxes resume on the following tick.

## Super allowance

Two character-defined `superButtons` map to deterministic input bits. Core activation requires 100 energy and an unused move ID, consumes the bar and records that ID in the snapshot’s `usedSupers` array. This array survives every life loss. The relay accepts eleven input bits, including both Supers. The UI reads energy and usage directly; it does not authorize moves.

## Online free-for-all

Room capacity is selected at creation (2–6). The server assigns stable seats and tags relayed inputs/hashes; clients cannot choose the sender seat. All slots must be ready before start. Rollback keeps separate remote histories, predictions and used inputs for every other seat, and confirms only frames received from all peers. Disconnect events carry a stable seat and the first missing input frame. All peers replay a forfeit at that frame and supply neutral inputs thereafter, so remaining players continue. Waiting-room departures free slots; an empty room is deleted. Nearest active opponent determines facing; melee contacts and pushboxes are resolved across all pairs. Projectiles hit the first intersecting opponent; attacks can hit several opponents simultaneously. Victory requires at most one fighter with lives remaining, including fighters waiting to respawn.
