import { test } from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { WebSocket } from "ws";
import {
  GameSimulation,
  hashState,
} from "../packages/game-core/simulation/GameSimulation.js";
import { RollbackManager } from "../packages/networking/RollbackManager.js";
import { Button } from "../packages/game-core/types.js";
import type { ServerMessage } from "../packages/shared/protocol.js";
for (const latency of [0, 50, 100, 150, 200])
  test(`two peers converge with ${latency}ms input latency and jitter`, () => {
    const a = new RollbackManager(new GameSimulation(), 0),
      b = new RollbackManager(new GameSimulation(), 1);
    const queue: {
      due: number;
      target: RollbackManager;
      frame: number;
      mask: number;
    }[] = [];
    const frames = 420;
    const mask = (seat: number, frame: number) =>
      frame < 180
        ? seat === 0
          ? Button.Right
          : Button.Left
        : frame % 40 === 0
          ? Button.Heavy
          : frame % 23 === 0
            ? Button.Special2
            : frame % 29 === 0
              ? Button.Special
              : frame % 17 === 0
                ? Button.Light
                : 0;
    for (
      let clock = 0;
      clock < 3000 &&
      (a.simulation.state.frame < frames || b.simulation.state.frame < frames);
      clock++
    ) {
      for (const [peer, index, target] of [
        [a, 0, b],
        [b, 1, a],
      ] as const) {
        if (peer.simulation.state.frame >= frames) continue;
        peer.schedule(
          mask(index, peer.simulation.state.frame + 2),
          (frame, input) =>
            queue.push({
              due: clock + Math.ceil(latency / 16.667) + (frame % 3),
              target,
              frame,
              mask: input,
            }),
        );
      }
      for (let i = queue.length - 1; i >= 0; i--)
        if (queue[i].due <= clock) {
          const item = queue.splice(i, 1)[0];
          item.target.receive(item.frame, item.mask);
        }
      if (a.simulation.state.frame < frames) a.tick();
      if (b.simulation.state.frame < frames) b.tick();
    }
    queue
      .sort((x, y) => x.frame - y.frame)
      .forEach((item) => item.target.receive(item.frame, item.mask));
    assert.equal(a.simulation.state.frame, frames);
    assert.equal(b.simulation.state.frame, frames);
    assert.equal(hashState(a.simulation.state), hashState(b.simulation.state));
    assert.equal(a.desync, "OK");
    assert.equal(b.desync, "OK");
    const baseline = new GameSimulation();
    for (let frame = 0; frame < frames; frame++)
      baseline.step(frame < 2 ? [0, 0] : [mask(0, frame), mask(1, frame)]);
    assert.equal(hashState(a.simulation.state), hashState(baseline.state));
  });
test("real WebSocket create/join/ready/input/hash/disconnect and validation", async () => {
  const child = spawn(
    process.execPath,
    ["--import", "tsx", "apps/server/src/index.ts"],
    { env: { ...process.env, PORT: "0" }, stdio: ["ignore", "pipe", "pipe"] },
  );
  const sockets: WebSocket[] = [];
  try {
    const port = await new Promise<number>((resolve, reject) => {
      const timeout = setTimeout(
        () => reject(new Error("Server startup timeout")),
        8000,
      );
      child.stdout.on("data", (data) => {
        const match = data.toString().match(/port (\d+)/);
        if (match) {
          clearTimeout(timeout);
          resolve(Number(match[1]));
        }
      });
      child.on("error", reject);
    });
    const connect = async () => {
      const socket = new WebSocket(`ws://localhost:${port}`);
      sockets.push(socket);
      await new Promise<void>((r, j) => {
        socket.once("open", () => r());
        socket.once("error", j);
      });
      return socket;
    };
    const messages = new Map<WebSocket, ServerMessage[]>();
    const a = await connect(),
      b = await connect();
    for (const s of [a, b]) {
      messages.set(s, []);
      s.on("message", (d) => messages.get(s)!.push(JSON.parse(d.toString())));
    }
    const next = async (socket: WebSocket, type: string) => {
      const start = Date.now();
      while (Date.now() - start < 3000) {
        const queue = messages.get(socket)!;
        const i = queue.findIndex((m) => m.type === type);
        if (i >= 0) return queue.splice(i, 1)[0];
        await new Promise((r) => setTimeout(r, 5));
      }
      throw new Error("Missing message " + type);
    };
    a.send(JSON.stringify({ type: "create", character: "prototype-a" }));
    const room = await next(a, "room");
    assert.equal(room.type, "room");
    if (room.type !== "room") return;
    assert.match(room.code, /^[A-Z0-9]{5}$/);
    b.send(
      JSON.stringify({
        type: "join",
        code: room.code,
        character: "prototype-b",
      }),
    );
    await next(b, "room");
    a.send(JSON.stringify({ type: "ready" }));
    b.send(JSON.stringify({ type: "ready" }));
    const starts = await Promise.all([next(a, "start"), next(b, "start")]);
    assert.deepEqual(starts[0], starts[1]);
    a.send(JSON.stringify({ type: "input", frame: 2, mask: Button.Light }));
    assert.deepEqual(await next(b, "input"), {
      type: "input",
      seat: 0,
      frame: 2,
      mask: Button.Light,
    });
    a.send(JSON.stringify({ type: "input", frame: 3, mask: 4096 }));
    const error = await next(a, "error");
    assert.equal(error.type, "error");
    a.send(JSON.stringify({ type: "hash", frame: 0, hash: "abc123" }));
    assert.deepEqual(await next(b, "hash"), {
      type: "hash",
      seat: 0,
      frame: 0,
      hash: "abc123",
    });
    b.close();
    await next(a, "left");
  } finally {
    for (const socket of sockets) socket.terminate();
    child.kill();
  }
});
