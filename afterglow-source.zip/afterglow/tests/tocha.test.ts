import { test } from "node:test";
import assert from "node:assert/strict";
import { GameSimulation, hashState } from "../packages/game-core/simulation/GameSimulation.js";
import { Button } from "../packages/game-core/types.js";
import { characters } from "../packages/game-core/characters/registry.js";
import { igniteTarget } from "../packages/game-core/simulation/StatusSystem.js";
import { tochaPose } from "../apps/client/src/rendering/TochaRenderer.js";
import { RollbackManager } from "../packages/networking/RollbackManager.js";
const moves = characters.tocha.moves;
function match(n = 2) {
  const sim = new GameSimulation(Array(n).fill("tocha"), false, undefined, n === 2 ? [0, 1] : Array.from({length:n}, (_, i) => i % 2));
  sim.state.phase = "fight"; sim.state.fighters.forEach(f => f.state = "Idle"); return sim;
}
function run(sim: GameSimulation, n: number, mask = 0) { for(let i=0;i<n;i++) sim.step([mask,0,0,0,0,0]); }
test("Tocha has two skins, punch/punch/kick chain, heavy kick and burning double punch", () => {
  assert.equal(characters.tocha.skins?.length, 2);
  const s=match(), f=s.state.fighters[0];
  s.step([Button.Light,0]); assert.equal(f.move,"jab"); run(s,3); s.step([Button.Light,0]); run(s,10); assert.equal(f.move,"cross");
  s.step([Button.Light,0]); run(s,14); assert.equal(f.move,"finisher");
  run(s,50); s.step([Button.Medium,0]); assert.equal(f.move,"heavy"); run(s,60);
  s.step([Button.Heavy,0]); assert.equal(f.move,"double"); assert.equal(moves.double.burn?.duration,120);
});
test("burn ticks for exactly 2/3 seconds during movement and hitstop without stun", () => {
  for(const duration of [120,180]) {
    const s=match(), target=s.state.fighters[0];
    igniteTarget(s.state,target,1,duration,10);
    const x=target.x; run(s,29,Button.Left); assert.equal(target.health,1000); assert.ok(target.x<x); assert.equal(target.stun,0);
    s.state.hitstop=200; run(s,duration-29); assert.equal(target.health,1000-duration/30*10);
    run(s,1); assert.equal(target.burnUntil,0); run(s,60); assert.equal(target.health,1000-duration/30*10);
  }
});
test("blocked and invulnerable targets cannot ignite; double punch and fireball burn on hit", () => {
  const s=match(), [a,b]=s.state.fighters;
  s.hit(0,moves.double,Button.Right,false,1); assert.equal(b.burnUntil,0); assert.equal(b.health,1000);
  b.stun=0;b.state="Idle";s.hit(0,moves.double,0,false,1); assert.equal(b.burnUntil,s.state.frame+120);
  b.burnUntil=0;b.invulnerableUntil=200;igniteTarget(s.state,b,0,180,10); assert.equal(b.burnUntil,0);
  const ball=match();ball.state.fighters[0].x=600;ball.state.fighters[1].x=900;ball.step([Button.Special,0]);run(ball,50);assert.ok(ball.state.fighters[1].burnUntil>ball.state.frame);
  assert.ok(a.meter>40);
});
test("ground sigil persists 4 seconds, is repeatable and damages only nearby enemies on same level", () => {
  const s=match(4);s.state.fighters.forEach((f,i)=>{f.x=1000+i*80;});
  s.step([Button.Special2,0,0,0]);run(s,24); assert.equal(s.state.hazards.length,1);
  const h=s.state.hazards[0], expiry=h.expiresAt;
  s.state.fighters[2].x=1000; s.state.fighters[3].x=1000;s.state.fighters[3].y=340;
  run(s,1);assert.equal(s.state.fighters[1].health,982);assert.equal(s.state.fighters[2].health,1000);assert.equal(s.state.fighters[3].health,1000);
  s.state.hitstop=300;run(s,expiry-s.state.frame-1);assert.equal(s.state.hazards.length,1);run(s,1);assert.equal(s.state.hazards.length,0);
});
test("On fire lasts 10 seconds, refreshes contact burn and boosts movement/attack speed by 50%", () => {
  const s=match(), f=s.state.fighters[0]; f.meter=100;s.step([Button.Super1,0]);run(s,18);
  assert.equal(f.onFireUntil-s.state.frame,600);assert.equal(f.meter,0);run(s,30);
  const x=f.x;run(s,10,Button.Right);assert.equal(f.x-x,75);
  s.step([Button.Light,0]);run(s,3);assert.equal(f.moveFrame,5); // 4 ticks advance 6 animation frames from -1
  f.move=null;f.state="Idle";s.state.fighters[1].x=f.x+64;run(s,35);const d=s.state.fighters[1];assert.ok(d.health<1000);assert.ok(d.burnUntil>=s.state.frame+179);
  const expiry=f.onFireUntil;s.state.hitstop=1000;run(s,expiry-s.state.frame);assert.equal(f.onFireUntil,0);
});
test("each Tocha super requires full energy and remains spent through death and respawn", () => {
  for(const button of [Button.Super1,Button.Super2]) {
    const s=match(),f=s.state.fighters[0]; f.meter=99;s.step([button,0]);assert.equal(f.move,null);run(s,10);
    f.meter=100;s.step([button,0]);assert.equal(f.usedSupers.length,1);assert.equal(f.meter,0);
    f.health=0;run(s,1);assert.equal(f.onFireUntil,0);assert.equal(f.burnUntil,0);run(s,120);
    f.meter=100;s.step([button,0]);assert.equal(f.move,null);assert.equal(f.usedSupers.length,1);
  }
});
test("666 Satan headbangs, launches one large homing pentagram and deals high damage", () => {
  const s=match(),[f,d]=s.state.fighters;f.meter=100;f.x=500;d.x=950;
  s.step([Button.Super2,0]);run(s,20);assert.ok([16,17].includes(tochaPose(f,characters.tocha)));
  run(s,70);assert.equal(s.state.projectiles.filter(p=>p.active).length,1);
  run(s,45);assert.equal(d.health,640);assert.equal(f.meter,0);
});
test("fire effects clear on defeat and cannot bypass respawn protection", () => {
  const s=match(),f=s.state.fighters[0];f.health=10;igniteTarget(s.state,f,1,180,10);f.onFireUntil=1000;
  run(s,30);assert.equal(f.lives,2);assert.equal(f.burnUntil,0);assert.equal(f.onFireUntil,0);
  run(s,120);igniteTarget(s.state,f,1,180,10);assert.equal(f.burnUntil,0);assert.equal(f.health,1000);
});
test("team fire, aura and sigils never damage teammates, and all status state replays identically", () => {
  const s=match(6);const [f,enemy,ally]=s.state.fighters;f.x=1000;enemy.x=1065;ally.x=1000;f.onFireUntil=600;
  igniteTarget(s.state,ally,0,180,10);assert.equal(ally.burnUntil,0);run(s,40);assert.equal(ally.health,1000);assert.ok(enemy.health<1000);
  const snap=s.snapshot();run(s,200);const hash=hashState(s.state);s.restore(snap);run(s,200);assert.equal(hashState(s.state),hash);
});
test("late online fire inputs converge through rollback in 2v2 and 3v3", () => {
  for(const n of [4,6]) {
    const baseline=match(n), predicted=match(n);for(const sim of [baseline,predicted]) sim.state.fighters.forEach((f,i)=>{f.x=500+i*90;f.meter=100;});
    const rb=new RollbackManager(predicted,0,0,8);
    for(let frame=0;frame<250;frame++) {
      const masks=Array.from({length:n},(_,seat)=>frame===0 ? seat%2 ? Button.Special : Button.Super1 : frame===70 ? Button.Special2 : 0);
      baseline.step(masks);rb.local.set(frame,masks[0]);rb.tick();
      for(let seat=1;seat<n;seat++) rb.receive(frame,masks[seat],seat);
    }
    assert.equal(hashState(predicted.state),hashState(baseline.state));
  }
});

test("recasting a pentagram does not shorten the existing sigil lifetime", () => {
  const s=match();s.step([Button.Special2,0]);run(s,60);const firstExpiry=s.state.hazards[0].expiresAt;
  s.step([Button.Special2,0]);run(s,24);assert.equal(s.state.hazards.length,2);assert.equal(s.state.hazards[0].expiresAt,firstExpiry);
});
