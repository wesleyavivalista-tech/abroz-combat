import { test } from "node:test";
import assert from "node:assert/strict";
import { InputManager } from "../apps/client/src/input/InputManager.js";
import { Button } from "../packages/game-core/types.js";
test("short Super key taps survive keyup before the next tick, exactly once", () => {
  const previous = Object.getOwnPropertyDescriptor(globalThis, "window");
  const handlers = new Map<string, (event: KeyboardEvent) => void>();
  Object.defineProperty(globalThis, "window", {
    configurable: true,
    value: {
      addEventListener: (
        name: string,
        handler: (event: KeyboardEvent) => void,
      ) => handlers.set(name, handler),
    },
  });
  try {
    const input = new InputManager();
    const event = (code: string) =>
      ({
        code,
        target: { matches: () => false },
        preventDefault() {},
      }) as unknown as KeyboardEvent;
    handlers.get("keydown")!(event("KeyO"));
    handlers.get("keyup")!(event("KeyO"));
    assert.equal(input.poll(0), Button.Super1);
    assert.equal(input.poll(0), 0);
    handlers.get("keydown")!(event("Digit8"));
    handlers.get("keyup")!(event("Digit8"));
    assert.equal(input.poll(0), 0);
    assert.equal(input.poll(1), Button.Super2);
    assert.equal(input.poll(1), 0);
    handlers.get("keydown")!(event("KeyP"));
    input.clear();
    assert.equal(input.poll(0), 0);
  } finally {
    if (previous) Object.defineProperty(globalThis, "window", previous);
    else Reflect.deleteProperty(globalThis, "window");
  }
});
